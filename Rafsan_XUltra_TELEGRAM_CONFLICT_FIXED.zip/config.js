import 'dotenv/config';
let _prefixes = process.env.PREFIXES ? process.env.PREFIXES.split(',') : ['.'];
try {
    const fs = await import('fs');
    const saved = JSON.parse(fs.readFileSync('./data/prefix.json', 'utf8'));
    if (Array.isArray(saved.prefixes) && saved.prefixes.length) _prefixes = saved.prefixes;
} catch {}
const config = {
    // Bot Identity
    botName: process.env.BOT_NAME || 'Rafsan-XUltra',
    botOwner: process.env.BOT_OWNER || 'Rafsan-XUltra',
    ownerNumber: process.env.OWNER_NUMBER || '8801787638926',
    // Sudo users (comma-separated WhatsApp numbers, country code, no +)
    sudoNumbers: (process.env.SUDO_NUMBERS || '8801787638926').split(',').map(n => n.replace(/\D/g, '')).filter(Boolean),
    author: process.env.AUTHOR || 'Rafsan-XUltra',
    packname: process.env.PACKNAME || 'Rafsan-XUltra',
    description: process.env.DESCRIPTION || 'High performance multi-device WhatsApp bot',
    version: '7.1.0',
    // Bot Config
    prefixes: _prefixes,
    prefix: _prefixes[0],
    commandMode: process.env.COMMAND_MODE || 'public',
    timeZone: process.env.TIMEZONE || 'Asia/Dhaka',
    // Links
    channelLink: process.env.CHANNEL_LINK || '',
    telegramPairLink: process.env.TELEGRAM_PAIR_LINK || 'https://t.me/+C2HaJVGB1pxjYzg1',
    telegramPairGroupId: process.env.TELEGRAM_PAIR_GROUP_ID || '-1003854943824',
    telegramOwnerId: process.env.TELEGRAM_OWNER_ID || '5951784848',
    // Telegram BotFather token. Prefer TELEGRAM_BOT_TOKEN in .env; the fallback lets you paste it here if needed.
    telegramBotToken: process.env.TELEGRAM_BOT_TOKEN || 'PASTE_YOUR_BOTFATHER_TOKEN_HERE',
    qasimApiKey: process.env.QASIM_API_KEY || 'qasim-dev',
    yoinkuApiKey: process.env.YOINKU_API_KEY || '',
    // Local WhatsApp startup pairing is disabled by default; Telegram /pair is the pairing entry point.
    enableLocalPairing: String(process.env.ENABLE_LOCAL_PAIRING || 'false').toLowerCase() === 'true',
    updateZipUrl: process.env.UPDATE_URL || 'https://example.com/Rafsan-X.zip',
    ytChannel: process.env.YT_CHANNEL || 'xafsan',
    // Session
    sessionId: process.env.SESSION_ID || '',
    pairingNumber: process.env.PAIRING_NUMBER || '',
    // Performance
    port: Number(process.env.PORT) || 5000,
    maxStoreMessages: Number(process.env.MAX_STORE_MESSAGES) || 20,
    tempCleanupInterval: Number(process.env.CLEANUP_INTERVAL) || 1 * 60 * 60 * 1000,
    storeWriteInterval: Number(process.env.STORE_WRITE_INTERVAL) || 10000,
    // API Keys
    giphyApiKey: process.env.GIPHY_API_KEY || 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
    removeBgKey: process.env.REMOVEBG_KEY || '',
    // Warn system
    warnCount: 3,
    // External APIs (merged from the Xafsan-xmd provider + existing Rafsan-XUltra APIs)
    APIs: {
        xteam: 'https://api.xteam.xyz',
        dzx: 'https://api.dhamzxploit.my.id',
        lol: 'https://api.lolhuman.xyz',
        violetics: 'https://violetics.pw',
        neoxr: 'https://api.neoxr.my.id',
        zenzapis: 'https://zenzapis.xyz',
        akuari: 'https://api.akuari.my.id',
        akuari2: 'https://apimu.my.id',
        nrtm: 'https://fg-nrtm.ddns.net',
        bg: 'http://bochil.ddns.net',
        fgmods: 'https://api-fgmods.ddns.net'
    },
    APIKeys: {
        'https://api.xteam.xyz': 'd90a9e986e18778b',
        'https://api.lolhuman.xyz': '85faf717d0545d14074659ad',
        'https://api.neoxr.my.id': process.env.NEOXR_KEY || 'yourkey',
        'https://violetics.pw': 'beta',
        'https://zenzapis.xyz': process.env.ZENZAPIS_KEY || 'yourkey',
        'https://api-fgmods.ddns.net': 'fg-dylux'
    },
    // Media APIs used by play/song/social download plugins. Keep these in config so
    // providers can be changed without rewriting command files.
    mediaApis: {
        youtubeAudio: process.env.YOUTUBE_AUDIO_API || 'https://api.neosoft.best/api/downloader/youtube',
        tiktok: process.env.TIKTOK_API || 'https://api.siputzx.my.id/api/d/tiktok',
        facebook: process.env.FACEBOOK_API || 'https://api.hanggts.xyz/download/facebook',
        facebookFallback: process.env.FACEBOOK_FALLBACK_API || 'https://gtech-api-xtp1.onrender.com/api/download/fb',
        snapchat: process.env.SNAPCHAT_API || 'https://discardapi.dpdns.org/api/dl/snapchat'
    },
    mediaApiKeys: {
        facebook: process.env.FACEBOOK_API_KEY || 'APIKEY',
        snapchat: process.env.SNAPCHAT_API_KEY || 'guru'
    }
};
export default config;
