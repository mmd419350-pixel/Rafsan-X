# Telegram Pair Conflict Fix

This build hardens the Telegram long-polling pair service.

## What was fixed
- Added a filesystem PID lock so only one Rafsan-X process on the same panel/container can poll a BotFather token at a time.
- Stale lock files are recovered automatically when the recorded PID is no longer running.
- Telegram HTTP errors now preserve the API error code.
- HTTP 409 / `terminated by other getUpdates request` no longer causes an endless reconnect/error spam loop. The polling loop stops cleanly instead.
- The temporary `/pair` "PAIRING STARTED" message variable is now scoped correctly, so pairing failures cannot throw a secondary `ReferenceError` while trying to clean up.
- Removed a duplicate `admins` switch branch in the message permission pipeline.
- Added the runtime lock file to `.gitignore`.

## Important
A Telegram BotFather token can still only have one active `getUpdates` polling consumer. If another separate server/container is running the same token, stop that other instance or use a different Telegram bot token. This build prevents the local process from creating an endless conflict loop; it cannot make Telegram allow two independent polling consumers for the same token.
