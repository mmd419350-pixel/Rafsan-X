export default {
    command: 'unmute', aliases: ['unsilence'], category: 'admin', description: 'Unmute the group', usage: '.unmute', groupOnly: true, adminOnly: true,
    async handler(sock, message, args, context) {
        const { chatId, channelInfo } = context;
        try { await sock.groupSettingUpdate(chatId, 'not_announcement'); return sock.sendMessage(chatId, { text: '🔊 *GROUP UNMUTED*\n\nসবাই আবার message করতে পারবেন। ❤️', ...channelInfo }, { quoted: message }); }
        catch (error) { console.error('Unmute error:', error); return sock.sendMessage(chatId, { text: '❌ Failed to unmute the group.', ...channelInfo }, { quoted: message }); }
    }
};
