export default {
  command: 'propuss',
  aliases: ['proposal', 'propose'],
  category: 'fun',
  description: 'Send a playful friendship proposal-style message',
  usage: '.propuss',
  cooldown: 2500,
  async handler(sock, message, args, context) {
    const chatId = context.chatId || message.key.remoteJid;
    const text =
`💌 *একটা ছোট্ট প্রস্তাব!*

আমি বড় কোনো কথা বলতে আসিনি…
শুধু একটা simple request—

🤝 *তুমি কি আমার ভালো বন্ধু হবে?*

হাসি, আড্ডা আর ভালো vibes দিয়ে
এই friendship-টা সুন্দর করে রাখি। 😄✨

— 🤖 *Rafsan-X Bot*`;
    return sock.sendMessage(chatId, { text }, { quoted: message });
  }
};
