import { resolveSnapchat, downloadBuffer } from '../lib/mediaDownloaders.js';

export default {
  command: 'snapchat', aliases: ['scspot', 'snapdl'], category: 'download',
  description: 'Download Snapchat Spotlight media', usage: '.snapchat <Snapchat URL>', cooldown: 3000,
  async handler(sock, message, args, context) {
    const chatId = context.chatId || message.key.remoteJid;
    const url = args.join(' ').trim();
    if (!url) return sock.sendMessage(chatId, { text: '👻 *SNAPCHAT DOWNLOADER*\n\nUsage: `.snapchat <Snapchat Spotlight URL>`' }, { quoted: message });
    if (!/https?:\/\/(?:www\.)?snapchat\.com\//i.test(url)) return sock.sendMessage(chatId, { text: '❌ Please send a valid Snapchat Spotlight link.' }, { quoted: message });
    try {
      await sock.sendMessage(chatId, { react: { text: '🔄', key: message.key } });
      const mediaList = await resolveSnapchat(url);
      for (const media of mediaList) {
        const caption = `👻 *Snapchat Downloader*\n\n${media.type === 'video' ? '🎬 Spotlight Video' : '🖼️ Spotlight Image'}\n⚡ *Rafsan-XUltra*`;
        try {
          if (media.type === 'video') await sock.sendMessage(chatId, { video: { url: media.url }, mimetype: 'video/mp4', caption }, { quoted: message });
          else await sock.sendMessage(chatId, { image: { url: media.url }, caption }, { quoted: message });
        } catch (directError) {
          console.error('[SNAPCHAT] direct send failed:', directError.message);
          const buffer = await downloadBuffer(media.url, { maxContentLength: 90 * 1024 * 1024, maxBodyLength: 90 * 1024 * 1024, headers: { Referer: 'https://www.snapchat.com/' } });
          if (media.type === 'video') await sock.sendMessage(chatId, { video: buffer, mimetype: 'video/mp4', caption }, { quoted: message });
          else await sock.sendMessage(chatId, { image: buffer, caption }, { quoted: message });
        }
      }
    } catch (error) {
      console.error('[SNAPCHAT]', error);
      await sock.sendMessage(chatId, { text: `❌ *Snapchat download failed.*\n\n${error?.message || 'The media provider failed.'}` }, { quoted: message });
    }
  }
};
