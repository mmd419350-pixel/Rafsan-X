export default {
  command: 'brackup',
  aliases: ['breakup', 'kbreakup'],
  category: 'fun',
  description: 'Send a playful Korean breakup-style letter',
  usage: '.brackup',
  cooldown: 2500,
  async handler(sock, message, args, context) {
    const chatId = context.chatId || message.key.remoteJid;
    const text =
`💔 *재미로 보내는 이별 편지*

우리의 마지막은…
생각보다 너무 빨리 왔네.

그동안 함께 웃고 떠들었던 시간,
이제는 좋은 추억으로 남겨둘게.

잘 지내고, 항상 행복하길 바랄게.
그리고 이건 그냥 *fun command*였다는 사실도 잊지 마! 😂

— 🤖 *Rafsan-X Bot*`;
    return sock.sendMessage(chatId, { text }, { quoted: message });
  }
};
