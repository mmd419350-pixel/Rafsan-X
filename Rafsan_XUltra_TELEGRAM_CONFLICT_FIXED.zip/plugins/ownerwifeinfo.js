import fs from 'fs';
import path from 'path';

const FILE = path.join(process.cwd(), 'data', 'ownerwifeinfo.json');
const DEFAULTS = {
  name: '𝐀𝐤𝐡𝐨𝐧𝐨 𝐣𝐢𝐛𝐨𝐧𝐞 𝐚𝐦𝐨𝐧 𝐤𝐞𝐰 𝐚𝐬𝐞 𝐧𝐢',
  age: '𝐉𝐚𝐧𝐢𝐧𝐚 𝐛𝐡𝐚𝐢',
  className: '𝐡𝐨𝐥𝐞 𝐣𝐢𝐠𝐠𝐞𝐬 𝐤𝐨𝐫𝐞 𝐛𝐨𝐥𝐛𝐨'
};
function load() {
  try {
    if (!fs.existsSync(path.dirname(FILE))) fs.mkdirSync(path.dirname(FILE), { recursive: true });
    if (!fs.existsSync(FILE)) fs.writeFileSync(FILE, JSON.stringify(DEFAULTS, null, 2));
    return { ...DEFAULTS, ...JSON.parse(fs.readFileSync(FILE, 'utf8')) };
  } catch { return { ...DEFAULTS }; }
}
export default {
  command: 'ownerwifeinfo',
  aliases: ['wifeinfo', 'owife'],
  category: 'info',
  description: 'Show owner special-person information',
  usage: '.ownerwifeinfo',
  async handler(sock, message, args, context) {
    const chatId = context.chatId || message.key.remoteJid;
    const d = load();
    const text =
`╭━━━〔 🌸 OWNER SPECIAL INFO 〕━━━╮
┃
┃ 👤 Name : ${d.name}
┃ 🎂 Age  : ${d.age}
┃ 🎓 Class: ${d.className}
┃
┃ ✨ A special profile in
┃    Rafsan-X's bot.
┃
┃ 🌷 Respect • Kindness • Good wishes
┃    make every bond brighter.
╰━━━━━━━━━━━━━━━━━━━━━━━━━━╯`;
    return sock.sendMessage(chatId, { text }, { quoted: message });
  }
};
