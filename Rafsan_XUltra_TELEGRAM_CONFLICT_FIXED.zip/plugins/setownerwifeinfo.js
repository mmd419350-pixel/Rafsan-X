import fs from 'fs';
import path from 'path';
import { isMainOwner } from '../lib/isOwner.js';

const FILE = path.join(process.cwd(), 'data', 'ownerwifeinfo.json');
const DEFAULTS = { name: '𝐀𝐤𝐡𝐨𝐧𝐨 𝐩𝐚𝐢 𝐧𝐚𝐢 𝐛𝐡𝐚𝐢', age: '𝐀𝐤𝐛𝐚𝐫 𝐩𝐞𝐲𝐞 𝐠𝐞𝐥𝐞 𝐬𝐨𝐛 𝐛𝐨𝐥𝐛𝐨', className: '𝐤𝐞𝐰 𝐧𝐚𝐢' };

function save(data) {
  fs.mkdirSync(path.dirname(FILE), { recursive: true });
  fs.writeFileSync(FILE, JSON.stringify(data, null, 2));
}
function clean(v) {
  return String(v || '').trim().replace(/\|/g, '');
}

export default {
  command: 'setownerwifeinfo',
  aliases: ['setwifeinfo'],
  category: 'owner',
  description: 'Change ownerwifeinfo name, age and class',
  usage: '.setownerwifeinfo | name | age | class',
  strictOwnerOnly: true,
  cooldown: 2000,
  async handler(sock, message, args, context) {
    const chatId = context.chatId || message.key.remoteJid;
    const senderId = context.senderId || message.key.participant || message.key.remoteJid;
    if (!message.key.fromMe && !(await isMainOwner(senderId, sock, chatId))) {
      return sock.sendMessage(chatId, { text: '👑 Only the main bot owner can use this command.' }, { quoted: message });
    }
    const raw = args.join(' ').trim();
    if (!raw) {
      return sock.sendMessage(chatId, {
        text: `⚙️ *SET OWNER WIFE INFO*\n\nUse:\n\`.setownerwifeinfo Name | Age | Class\`\n\nExample:\n\`.setownerwifeinfo 𝐘𝐨𝐮'𝐫 𝐠𝐟 𝐧𝐚𝐦𝐞 | 𝐡𝐚𝐫 𝐚𝐠𝐞 | 𝐡𝐚𝐫 𝐜𝐥𝐚𝐬𝐬\``
      }, { quoted: message });
    }
    const parts = raw.split('|').map(clean);
    if (parts.length < 3 || parts.slice(0,3).some(x => !x)) {
      return sock.sendMessage(chatId, { text: '❌ Format: `.setownerwifeinfo Name | Age | Class`' }, { quoted: message });
    }
    const data = { name: parts[0].slice(0,80), age: parts[1].slice(0,40), className: parts[2].slice(0,60) };
    save(data);
    return sock.sendMessage(chatId, {
      text: `✅ *OWNERWIFEINFO UPDATED*\n\n👤 ${data.name}\n🎂 ${data.age}\n🎓 ${data.className}`
    }, { quoted: message });
  }
};
