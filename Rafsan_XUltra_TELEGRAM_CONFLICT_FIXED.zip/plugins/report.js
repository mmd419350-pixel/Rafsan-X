import config from '../config.js';

function normalizeJid(value = '') {
    if (!value) return '';
    if (value.includes('@')) return value;
    const digits = value.replace(/\D/g, '');
    return digits ? `${digits}@s.whatsapp.net` : '';
}

function getTarget(message, args) {
    const mentioned = message?.message?.extendedTextMessage?.contextInfo?.mentionedJid ||
        message?.message?.imageMessage?.contextInfo?.mentionedJid ||
        message?.message?.videoMessage?.contextInfo?.mentionedJid || [];
    if (mentioned[0]) return mentioned[0];

    const quoted = message?.message?.extendedTextMessage?.contextInfo?.participant;
    if (quoted) return quoted;

    const candidate = args[0] || '';
    return normalizeJid(candidate);
}

export default {
    command: 'report',
    aliases: ['reportuser', 'complain'],
    category: 'group',
    description: 'Send a group member report to the bot owner',
    usage: '.report @user <reason> (or reply to their message)',
    groupOnly: true,
    cooldown: 5000,
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const target = getTarget(message, args);
        const mentioned = message?.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0] ||
            message?.message?.imageMessage?.contextInfo?.mentionedJid?.[0] ||
            message?.message?.videoMessage?.contextInfo?.mentionedJid?.[0];
        const quoted = message?.message?.extendedTextMessage?.contextInfo?.participant;
        const explicitTarget = !!mentioned || (!quoted && !!args[0] && !!normalizeJid(args[0]));
        const reason = (explicitTarget ? args.slice(1) : args).join(' ').trim() || 'No reason provided.';
        if (!target) {
            return sock.sendMessage(chatId, {
                text: '📋 *REPORT USER*\n\nReply to the member\'s message and use:\n`.report <reason>`\n\nOr:\n`.report @user <reason>`'
            }, { quoted: message });
        }

        const sender = message.key.participant || message.key.remoteJid;
        const ownerNumber = String(config.ownerNumber || '').replace(/\D/g, '');
        if (!ownerNumber) {
            return sock.sendMessage(chatId, { text: '❌ Owner number is not configured.' }, { quoted: message });
        }
        const ownerJid = `${ownerNumber}@s.whatsapp.net`;
        let groupName = chatId;
        try { groupName = (await sock.groupMetadata(chatId)).subject || chatId; } catch {}

        const text =
            `🚨 *GROUP MEMBER REPORT*\n\n` +
            `👤 *Reported:* @${target.split('@')[0]}\n` +
            `📝 *Reason:* ${reason}\n` +
            `👮 *Reported by:* @${String(sender).split('@')[0]}\n` +
            `👥 *Group:* ${groupName}\n` +
            `🆔 *Group ID:* ${chatId}\n\n` +
            `_Please review this report and take appropriate group-level action if needed._`;

        try {
            await sock.sendMessage(ownerJid, { text, mentions: [target, sender] });
            return sock.sendMessage(chatId, {
                text: `✅ Report sent to the bot owner for review.\n\n👤 @${target.split('@')[0]}`,
                mentions: [target]
            }, { quoted: message });
        } catch (error) {
            return sock.sendMessage(chatId, { text: `❌ Could not send the report: ${error.message}` }, { quoted: message });
        }
    }
};
