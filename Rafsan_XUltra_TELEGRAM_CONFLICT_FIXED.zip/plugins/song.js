import yts from 'yt-search';
import { resolveYouTubeAudio, cleanFileName, downloadBuffer } from '../lib/mediaDownloaders.js';

async function sendAudio(sock, chatId, message, audio) {
  try {
    await sock.sendMessage(chatId, {
      audio: { url: audio.url },
      mimetype: 'audio/mpeg',
      fileName: audio.filename || `${cleanFileName(audio.title)}.mp3`,
      ptt: false
    }, { quoted: message });
  } catch (directError) {
    console.error('[SONG] direct send failed:', directError.message);
    const buffer = await downloadBuffer(audio.url, { maxContentLength: 55 * 1024 * 1024, maxBodyLength: 55 * 1024 * 1024 });
    await sock.sendMessage(chatId, {
      audio: buffer,
      mimetype: 'audio/mpeg',
      fileName: audio.filename || `${cleanFileName(audio.title)}.mp3`,
      ptt: false
    }, { quoted: message });
  }
}

export default {
  command: 'song', aliases: ['audio', 'mp3'], category: 'music',
  description: 'Search YouTube and send the song as MP3', usage: '.song <song name>', cooldown: 3000,
  async handler(sock, message, args, context) {
    const chatId = context.chatId || message.key.remoteJid;
    const query = args.join(' ').trim();
    if (!query) return sock.sendMessage(chatId, {
      text: '🎵 *SONG DOWNLOADER*\n\nUsage: `.song <song name>`\n\n⚠️ Download only media you have permission to use.'
    }, { quoted: message });

    try {
      const result = await yts(query);
      const video = result?.videos?.[0];
      if (!video?.url) throw new Error('No matching song was found.');

      const audio = await resolveYouTubeAudio(video.url);
      const title = audio.title || video.title || query;
      const thumb = audio.thumbnail || video.thumbnail;
      const details = `╭━━〔 🎵 SONG DETAILS 〕━━╮\n│ 🎧 Title: *${title}*\n│ ⏱️ Duration: *${audio.duration || video.timestamp || 'Unknown'}*\n│ 🎤 Source: *YouTube*\n╰━━━━━━━━━━━━━━━━━━━━╯\n\n⏳ *Preparing your MP3…*`;

      if (thumb) {
        try { await sock.sendMessage(chatId, { image: { url: thumb }, caption: details }, { quoted: message }); }
        catch { await sock.sendMessage(chatId, { text: details }, { quoted: message }); }
      } else {
        await sock.sendMessage(chatId, { text: details }, { quoted: message });
      }

      await sendAudio(sock, chatId, message, { ...audio, title });
    } catch (error) {
      console.error('[SONG]', error);
      await sock.sendMessage(chatId, {
        text: `❌ *Song download failed.*\n\n${error?.message || 'The audio provider is temporarily unavailable.'}`
      }, { quoted: message });
    }
  }
};
