import store, { getCurrentSessionKey } from '../lib/lightweight_store.js';

export async function addCommandReaction(sock, message) {
  try {
    if (!message?.key?.id) return;
    const sid = String(sock?.sessionKey || getCurrentSessionKey() || 'main');
    const saved = await store.getSetting(sid, 'commandReaction').catch(() => null);
    if (!(saved?.enabled ?? saved)) return;
    await sock.sendMessage(message.key.remoteJid, { react: { text: '⏳', key: message.key } });
  } catch (e) { console.error('[CMDREACT]', e?.message || e); }
}
export async function setCommandReactState(sock, state) {
  const sid = String(sock?.sessionKey || getCurrentSessionKey() || 'main');
  await store.saveSetting(sid, 'commandReaction', { enabled: Boolean(state) });
}
export default {
  command: 'cmdreact', aliases: ['creact','commandreact'], category: 'owner',
  description: 'Session-scoped command reactions', usage: '.cmdreact on/off', ownerOnly: true,
  async handler(sock, message, args, context) {
    const chatId = context.chatId || message.key.remoteJid;
    const action = String(args[0] || '').toLowerCase();
    if (!['on','off'].includes(action)) return sock.sendMessage(chatId, { text: 'Use `.cmdreact on` or `.cmdreact off`.' }, { quoted: message });
    await setCommandReactState(sock, action === 'on');
    return sock.sendMessage(chatId, { text: action === 'on' ? '🟢 *Command React ON*' : '🔴 *Command React OFF*' }, { quoted: message });
  }
};
