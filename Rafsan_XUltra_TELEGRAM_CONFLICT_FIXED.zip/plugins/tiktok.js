import { resolveTikTok, downloadBuffer } from '../lib/mediaDownloaders.js';

export default {
  command: 'tiktok', aliases: ['tt', 'ttdl', 'tiktokdl'], category: 'download',
  description: 'Download a TikTok video', usage: '.tiktok <TikTok URL>', cooldown: 3000,
  async handler(sock, message, args, context) {
    const chatId = context.chatId || message.key.remoteJid;
    const url = args.join(' ').trim();
    if (!url) return sock.sendMessage(chatId, { text: '🎬 *TIKTOK*\n\nUsage: `.tiktok <TikTok URL>`' }, { quoted: message });
    if (!/https?:\/\/(?:www\.|vm\.|vt\.)?tiktok\.com\//i.test(url)) {
      return sock.sendMessage(chatId, { text: '❌ Please send a valid TikTok link.' }, { quoted: message });
    }
    try {
      await sock.sendMessage(chatId, { react: { text: '🔄', key: message.key } });
      const result = await resolveTikTok(url);
      try {
        await sock.sendMessage(chatId, { video: { url: result.videoUrl }, mimetype: 'video/mp4', caption: `🎬 *TikTok Downloader*\n\n✨ ${result.title || 'TikTok Video'}\n\n⚡ *Rafsan-XUltra*` }, { quoted: message });
      } catch (directError) {
        console.error('[TIKTOK] direct send failed:', directError.message);
        const buffer = await downloadBuffer(result.videoUrl, { maxContentLength: 90 * 1024 * 1024, maxBodyLength: 90 * 1024 * 1024, headers: { Referer: 'https://www.tiktok.com/' } });
        await sock.sendMessage(chatId, { video: buffer, mimetype: 'video/mp4', caption: `🎬 *TikTok Downloader*\n\n✨ ${result.title || 'TikTok Video'}\n\n⚡ *Rafsan-XUltra*` }, { quoted: message });
      }
    } catch (error) {
      console.error('[TIKTOK]', error);
      await sock.sendMessage(chatId, { text: `❌ *TikTok download failed.*\n\n${error?.message || 'All available TikTok providers failed.'}` }, { quoted: message });
    }
  }
};
