import { requestPairing } from '../lib/cloneManager.js';

export default {
    command: 'pair',
    aliases: ['paircode', 'clonepair'],
    category: 'general',
    description: 'Pair your own WhatsApp number as an independent bot session',
    usage: '.pair 8801XXXXXXXXX',
    cooldown: 8000,
    async handler(sock, message, args, context) {
        const { chatId } = context;
        const query = args.join('').trim();
        if (!query) {
            return await sock.sendMessage(chatId, {
                text: `╭━━━〔 🔗 PAIRING 〕━━━╮\n┃ Usage: *.pair 8801XXXXXXXXX*\n┃\n┃ Use your own WhatsApp number\n┃ with country code, without +.\n╰━━━━━━━━━━━━━━━━━━━━╯`
            }, { quoted: message });
        }

        const number = query.replace(/[^0-9]/g, '');
        if (!/^\d{10,15}$/.test(number)) {
            return await sock.sendMessage(chatId, {
                text: `❌ *Invalid number.*\n\nExample: *.pair 8801781234567*\nUse country code without + or spaces.`
            }, { quoted: message });
        }

        await sock.sendMessage(chatId, {
            text: `⚡ *Generating your private pairing code...*\n\n📱 Number: *${number}*\n🔐 No external pairing server is being used.`
        }, { quoted: message });

        try {
            const result = await requestPairing(number, {
                sock,
                chatId,
                message
            });

            if (result.alreadyLinked) {
                return await sock.sendMessage(chatId, {
                    text: `🟢 *Already Linked*\n\nThe number *${number}* already has a saved bot session.`,
                }, { quoted: message });
            }

            if (!result.code) throw new Error('Pairing code was not generated.');

            const displayCode = String(result.code).toUpperCase();
            const copyCode = displayCode.replace(/-/g, '');
            const text = `╭━━━〔 🔐 PAIRING CODE 〕━━━╮\n┃ 📱 Number: *${number}*\n┃ 🔑 Code: *${displayCode}*\n┃ 🟢 Session: *Independent*\n╰━━━━━━━━━━━━━━━━━━━━╯\n\n*Link this number:*\n1️⃣ WhatsApp → Settings\n2️⃣ Linked Devices\n3️⃣ Link a Device\n4️⃣ Link with phone number instead\n5️⃣ Enter the code above\n\n📋 *Copy-ready code:* \`${copyCode}\`\n\n⚠️ Only link your own WhatsApp account.\n💾 After linking, the session is saved and auto-reconnect is enabled.`;
            await sock.sendMessage(chatId, { text }, { quoted: message });
            // Standalone code message makes the pairing value easy to long-press and copy.
            await sock.sendMessage(chatId, { text: `🔑 *PAIRING CODE*\n\n\`${displayCode}\`` }, { quoted: message });
        } catch (error) {
            console.error('[PAIR]', error);
            await sock.sendMessage(chatId, {
                text: `❌ *Pairing failed.*\n\nReason: ${error.message || 'Unknown error'}\n\nPlease check the number and try again after a short moment.`
            }, { quoted: message });
        }
    }
};
