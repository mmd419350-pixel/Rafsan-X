import { delay } from '@whiskeysockets/baileys';
import isAdmin from '../lib/isAdmin.js';

export default {
  command: 'promoteall',
  aliases: ['makeadminall'],
  category: 'owner',
  description: 'Promote all eligible group members',
  usage: '.promoteall',
  groupOnly: true,
  ownerOnly: true,
  strictOwnerOnly: true,
  cooldown: 10000,
  async handler(sock, message, args, context) {
    const { chatId, channelInfo } = context;
    const adminCheck = await isAdmin(sock, chatId, context.senderId, { force: true });
    if (!adminCheck.isBotAdmin) {
      return sock.sendMessage(chatId, {
        text: '❌ *BOT ADMIN REQUIRED*\n\n👑 Make the bot an admin in this group first.\nThen use `.promoteall` again.',
        ...channelInfo
      }, { quoted: message });
    }
    try {
      const meta = adminCheck.metadata || await sock.groupMetadata(chatId);
      const ps = meta.participants || [];
      const botIds = new Set([sock.user?.id, sock.user?.lid, sock.user?.jid].filter(Boolean).flatMap(v => [String(v), String(v).split(':')[0], String(v).split('@')[0], String(v).split(':')[0].split('@')[0]]));
      const matches = (p, set) => [p.id, p.lid, p.phoneNumber, p.jid].filter(Boolean).some(v => {
        const s = String(v);
        return set.has(s) || set.has(s.split(':')[0]) || set.has(s.split('@')[0]) || set.has(s.split(':')[0].split('@')[0]);
      });
      const targets = ps.filter(p => !p.admin && !matches(p, botIds)).map(p => p.id || p.lid || p.phoneNumber).filter(Boolean);
      if (!targets.length) return sock.sendMessage(chatId, { text: 'ℹ️ *No regular members to promote.*', ...channelInfo }, { quoted: message });
      let done = 0;
      for (const jid of targets) {
        try {
          const r = await sock.groupParticipantsUpdate(chatId, [jid], 'promote');
          if (!Array.isArray(r) || r.some(x => String(x.status) === '200')) done++;
        } catch (e) { console.error('promoteall target', e.message); }
        await delay(700);
      }
      return sock.sendMessage(chatId, {
        text: `👑 *PROMOTE ALL COMPLETE*\n\n👥 Members targeted: ${targets.length}\n✅ Promoted: ${done}\n\n⏳ A small delay is used to reduce rate-limit problems.`,
        ...channelInfo
      }, { quoted: message });
    } catch (e) {
      return sock.sendMessage(chatId, { text: `❌ *Promoteall failed:* ${e.message || 'Unknown error'}`, ...channelInfo }, { quoted: message });
    }
  }
};
