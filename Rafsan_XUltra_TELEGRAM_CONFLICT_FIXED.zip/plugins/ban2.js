import { setGroupBotEnabled } from './botgroup.js';

export default {
    command: 'ban2',
    aliases: [],
    category: 'admin',
    description: 'Disable this bot session only in the current group',
    usage: '.ban2',
    groupOnly: true,
    adminOnly: true,
    cooldown: 1000,
    async handler(sock, message, _args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const sessionId = sock.sessionKey || 'main';
        await setGroupBotEnabled(chatId, false, sessionId);
        await sock.sendMessage(chatId, {
            text: `╭━━〔 🔴 BOT OFF — THIS GROUP ONLY 〕━━╮
┃
┃ ⛔ Status : OFF
┃ 🆔 Session : ${sessionId}
┃
┃ এই group-এ এই bot session আর
┃ command/automatic group feature চালাবে না।
┃
┃ 🟢 আবার চালু করতে:
┃    .unban2
┃
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯`
        }, { quoted: message });
    }
};
