export default {
    command: 'admins',
    aliases: ['tagadmins', 'adminlist'],
    category: 'group',
    description: 'Tag all group admins',
    usage: '.admins',
    groupOnly: true,
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        try {
            const metadata = await sock.groupMetadata(chatId);
            const admins = (metadata.participants || []).filter(p => p.admin).map(p => p.id).filter(Boolean);
            if (!admins.length) return sock.sendMessage(chatId, { text: 'ℹ️ No group admins found.' }, { quoted: message });
            const text = `╭━━〔 👑 𝐆𝐑𝐎𝐔𝐏 𝐀𝐃𝐌𝐈𝐍𝐒 〕━━╮\n┃ 🔔 Admin attention please!\n╰━━━━━━━━━━━━━━━━━━━━━━━━╯\n\n${admins.map((jid, i) => `${i + 1}. @${jid.split('@')[0]}`).join('\n')}`;
            await sock.sendMessage(chatId, { text, mentions: admins }, { quoted: message });
        } catch (error) {
            console.error('[ADMINS]', error);
            await sock.sendMessage(chatId, { text: `❌ Admin tag failed: ${error.message}` }, { quoted: message });
        }
    }
};
