import store from '../lib/lightweight_store.js';

const recentDemotions = new Map(); // group -> Map(actor -> timestamps)
const WINDOW_MS = 4000;
const TRIGGER_COUNT = 4;

function token(v) {
  return String(v || '').trim().split(':')[0].split('@')[0];
}
function ids(...vals) {
  const s = new Set();
  for (const v of vals) {
    if (!v) continue;
    const raw = String(v);
    s.add(raw);
    s.add(token(raw));
  }
  return s;
}
function same(a, set) {
  return [...ids(a)].some(x => set.has(x));
}

export default {
  command: 'antidemote',
  aliases: ['antidemoteall'],
  category: 'admin',
  description: 'Protect admins from rapid repeated demotions',
  usage: '.antidemote [on|off|status]',
  groupOnly: true,
  adminOnly: true,
  async handler(sock, message, args, context) {
    const { chatId, channelInfo } = context;
    const action = (args[0] || 'status').toLowerCase();
    const cur = await store.getSetting(chatId, 'antidemote') || { enabled: false };

    if (!['on','off','status'].includes(action)) {
      return sock.sendMessage(chatId, {
        text: '❌ Use: `.antidemote on` | `.antidemote off` | `.antidemote status`',
        ...channelInfo
      }, { quoted: message });
    }
    if (action === 'status') {
      return sock.sendMessage(chatId, {
        text: `🛡️ *ANTIDEMOTE STATUS*\n\n${cur.enabled ? '🟢 ON' : '🔴 OFF'}\n\n⚡ Trigger: 4 admin demotions within 4 seconds\n🎯 Action: Only the person doing the rapid demotions is demoted.`,
        ...channelInfo
      }, { quoted: message });
    }
    cur.enabled = action === 'on';
    await store.saveSetting(chatId, 'antidemote', cur);
    if (!cur.enabled) recentDemotions.delete(chatId);
    return sock.sendMessage(chatId, {
      text: `🛡️ *ANTIDEMOTE ${cur.enabled ? 'ON 🟢' : 'OFF 🔴'}*\n\n${cur.enabled ? 'Rapid admin-demotion protection is active.' : 'Protection is disabled.'}`,
      ...channelInfo
    }, { quoted: message });
  },

  async handleEvent(sock, id, participants, author) {
    const cur = await store.getSetting(id, 'antidemote');
    if (!cur?.enabled || !author || !participants?.length) return;

    try {
      const meta = await sock.groupMetadata(id);
      const actorSet = ids(author);
      const botSet = ids(
        sock.user?.id, sock.user?.lid, sock.user?.jid,
        sock.authState?.creds?.me?.id, sock.authState?.creds?.me?.lid
      );
      const creatorSet = ids(meta.owner, meta.ownerLid);

      const actorParticipant = (meta.participants || []).find(p =>
        [...ids(p.id, p.lid, p.phoneNumber, p.jid)].some(x => actorSet.has(x))
      );
      if (!actorParticipant?.admin) return;

      // Resolve LID <-> JID through group metadata so the bot itself is
      // never punished when the bot account performs demotions.
      const actorResolved = ids(
        author, actorParticipant.id, actorParticipant.lid,
        actorParticipant.phoneNumber, actorParticipant.jid
      );
      if ([...actorResolved].some(x => botSet.has(x)) ||
          [...actorResolved].some(x => creatorSet.has(x))) return;

      const now = Date.now();
      let groupMap = recentDemotions.get(id);
      if (!groupMap) {
        groupMap = new Map();
        recentDemotions.set(id, groupMap);
      }

      const old = (groupMap.get(token(author)) || []).filter(ts => now - ts <= WINDOW_MS);
      const count = old.length + Math.max(1, participants.length);
      const next = [...old, ...Array.from({ length: Math.max(1, participants.length) }, () => now)];
      groupMap.set(token(author), next);

      if (count >= TRIGGER_COUNT) {
        groupMap.delete(token(author));
        try {
          await sock.groupParticipantsUpdate(id, [author], 'demote');
          await sock.sendMessage(id, {
            text: `🛡️ *ANTIDEMOTE ACTIVE*\n\n@${token(author)} was demoted for rapidly demoting multiple group admins.\n\n⚡ Limit: ${TRIGGER_COUNT} demotions / ${WINDOW_MS / 1000}s`,
            mentions: [author]
          });
        } catch (e) {
          console.error('[ANTIDEMOTE] actor demotion failed:', e.message);
        }
      }
    } catch (e) {
      console.error('[ANTIDEMOTE] event error:', e.message);
    }
  }
};
