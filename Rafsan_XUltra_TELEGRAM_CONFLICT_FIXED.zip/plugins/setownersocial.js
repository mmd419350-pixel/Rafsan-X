import fs from 'fs';
import path from 'path';
import { isMainOwner } from '../lib/isOwner.js';

const FILE = path.join(process.cwd(), 'data', 'ownersocial.json');
const DEFAULTS = {
  facebook: 'https://facebook.com/example',
  tiktok: 'https://tiktok.com/@example',
  youtube: 'https://youtube.com/@example',
  whatsapp: '+8801000000000',
  contact: '+8801000000001'
};

function save(d) {
  fs.mkdirSync(path.dirname(FILE), { recursive: true });
  fs.writeFileSync(FILE, JSON.stringify(d, null, 2));
}

export default {
  command: 'setownersocial',
  aliases: ['setowner-social'],
  category: 'owner',
  description: 'Set owner social/contact information',
  usage: '.setownersocial Facebook | TikTok | YouTube | WhatsApp | Contact',
  strictOwnerOnly: true,
  cooldown: 1500,
  async handler(sock, message, args, context) {
    const chatId = context.chatId || message.key.remoteJid;
    const sender = context.senderId || message.key.participant || message.key.remoteJid;
    if (!message.key.fromMe && !(await isMainOwner(sender, sock, chatId))) {
      return sock.sendMessage(chatId, { text: '👑 Only the main owner can use this command.' }, { quoted: message });
    }
    const parts = args.join(' ').split('|').map(x => x.trim());
    if (parts.length < 5 || parts.some(x => !x)) {
      return sock.sendMessage(chatId, {
        text: '❌ Use:\n.setownersocial Facebook | TikTok | YouTube | WhatsApp | Contact'
      }, { quoted: message });
    }
    save({
      facebook: parts[0],
      tiktok: parts[1],
      youtube: parts[2],
      whatsapp: parts[3],
      contact: parts.slice(4).join(' | ')
    });
    return sock.sendMessage(chatId, { text: '✅ *Owner social information updated successfully.*\n\nUse `.ownersocial` to view it.' }, { quoted: message });
  }
};
