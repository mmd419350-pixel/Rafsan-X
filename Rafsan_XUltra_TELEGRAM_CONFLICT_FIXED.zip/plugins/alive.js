import os from 'os';
import process from 'process';

function formatUptime(totalSeconds) {
    let s = Math.max(0, Math.floor(Number(totalSeconds) || 0));
    const d = Math.floor(s / 86400); s %= 86400;
    const h = Math.floor(s / 3600); s %= 3600;
    const m = Math.floor(s / 60); s %= 60;
    const parts = [];
    if (d) parts.push(`${d}d`);
    if (h) parts.push(`${h}h`);
    if (m) parts.push(`${m}m`);
    if (s || !parts.length) parts.push(`${s}s`);
    return parts.join(' ');
}

export default {
    command: 'alive',
    aliases: ['status'],
    category: 'general',
    description: 'Check bot status and system information',
    usage: '.alive',
    isPrefixless: true,
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        try {
            const totalMem = os.totalmem() / 1024 / 1024;
            const freeMem = os.freemem() / 1024 / 1024;
            const usedMem = Math.max(0, totalMem - freeMem);
            const load = os.loadavg?.()[0] || 0;
            const cpuCount = os.cpus()?.length || 1;
            const cpu = Math.min(100, Math.max(0, (load / cpuCount) * 100));
            const uptime = formatUptime(process.uptime());
            const text = `╭━━━〔 ⚡ 𝐑𝐀𝐅𝐒𝐀𝐍-𝐗𝐔𝐋𝐓𝐑𝐀 〕━━━╮
┃ 🟢 Status   : ONLINE & READY
┃ 💎 Version  : ${context.config?.version || '7.1.0'}
┃ ⏱️ Uptime   : ${uptime}
┃ 💾 RAM      : ${usedMem.toFixed(0)} MB / ${totalMem.toFixed(0)} MB
┃ 🧠 CPU      : ${cpu.toFixed(1)}%
┃ 🧩 Plugins  : ${context.config?.botName ? 'LOADED' : 'READY'}
┃ 🖥️ Node     : ${process.version}
╰━━━━━━━━━━━━━━━━━━━━━━━━━━╯

╭──❍「 🚀 𝐒𝐘𝐒𝐓𝐄𝐌 𝐇𝐄𝐀𝐋𝐓𝐇 」❍
├• ⚡ Engine  : Baileys Multi-Device
├• 🛡️ Security: Session Isolation ON
├• 📡 Response: Stable & Active
╰──────────────────────────╯

🌙 *ইসলামিক স্মরণ:*
“নিশ্চয়ই আল্লাহর স্মরণেই অন্তরসমূহ প্রশান্ত হয়।”
— সূরা আর-রাদ ১৩:২৮

🤍 আল্লাহ আমাদের সবাইকে শান্তি ও হেদায়েত দান করুন।`;
            await sock.sendMessage(chatId, { text }, { quoted: message });
        } catch (error) {
            console.error('[ALIVE]', error);
            await sock.sendMessage(chatId, { text: '❌ Bot status পাঠাতে সমস্যা হয়েছে। একটু পরে আবার চেষ্টা করুন।' }, { quoted: message });
        }
    }
};
