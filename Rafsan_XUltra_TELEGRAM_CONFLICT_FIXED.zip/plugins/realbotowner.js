const owner={
 name:'Rafsan Talukder', age:'19 years', className:'2nd year', relationship:'Broken',
 district:'Sylhet / Moulvibazar', country:'Bangladesh', profession:'Bot Creator & Editor',
 facebook:'https://www.facebook.com/profile.php?id=61591995761897',
 tiktok:'https://tiktok.com/@im_rafsan_34',
 youtube:'https://www.youtube.com/@XafsanXTach',
 whatsapp:'+8801787638926', contact:'+8801630839731'
};
export default {command:'realbotowner',aliases:['myowner','ownerprofile'],category:'info',description:'Show the bot owner profile and social links',usage:'.realbotowner',async handler(sock,message,args,context){const chatId=context.chatId||message.key.remoteJid;const t=`╭━━〔 👑 REAL BOT OWNER 〕━━╮
┃
┃ 👤 Name        : ${owner.name}
┃ 🎂 Age         : ${owner.age}
┃ 🎓 Class       : ${owner.className}
┃ 💔 Relationship: ${owner.relationship}
┃ 📍 District    : ${owner.district}
┃ 🌍 Country     : ${owner.country}
┃ 💻 Profession  : ${owner.profession}
┃
┃ 🌐 Facebook : ${owner.facebook}
┃ 🎵 TikTok   : ${owner.tiktok}
┃ ▶️ YouTube  : ${owner.youtube}
┃ 💬 WhatsApp : ${owner.whatsapp}
┃ ☎️ Contact  : ${owner.contact}
┃
╰━━━━━━━━━━━━━━━━━━━━━━╯`;return sock.sendMessage(chatId,{text:t},{quoted:message});}};