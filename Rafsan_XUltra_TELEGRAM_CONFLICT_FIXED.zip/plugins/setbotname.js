import { isMainOwner } from '../lib/isOwner.js';
import { saveBotSettings } from '../lib/sessionSettings.js';

export default {
    command: 'setbotname',
    aliases: ['botname'],
    category: 'owner',
    description: 'Change the bot name shown in menus and bot info',
    usage: '.setbotname <new bot name>',
    strictOwnerOnly: true,
    cooldown: 2000,
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const senderId = context.senderId || message.key.participant || message.key.remoteJid;
        if (!message.key.fromMe && !(await isMainOwner(senderId, sock, chatId))) {
            return sock.sendMessage(chatId, { text: '👑 *Only the main bot owner can use this command.*' }, { quoted: message });
        }
        const name = args.join(' ').trim();
        if (!name) {
            return sock.sendMessage(chatId, {
                text: '❌ *Please provide a bot name.*\n\nExample: `.setbotname Rafsan-X`'
            }, { quoted: message });
        }
        if (name.length > 60) {
            return sock.sendMessage(chatId, { text: '❌ Bot name must be 60 characters or less.' }, { quoted: message });
        }
        saveBotSettings({ botName: name }, sock);
        return sock.sendMessage(chatId, {
            text: `✅ *Bot name updated successfully!*\n\n🤖 New Name: *${name}*\n\nUse \`.menu\` to see the updated name.`
        }, { quoted: message });
    }
};
