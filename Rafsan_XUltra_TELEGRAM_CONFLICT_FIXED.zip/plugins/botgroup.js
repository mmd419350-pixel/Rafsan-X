import fs from 'fs';
import path from 'path';

function safeKey(value) {
    return String(value || 'main').replace(/[^0-9A-Za-z._-]/g, '_').slice(0, 120) || 'main';
}
function fileFor(sessionId) {
    const dir = path.join(process.cwd(), 'data', 'sessions', safeKey(sessionId));
    fs.mkdirSync(dir, { recursive: true });
    return path.join(dir, 'groupBotState.json');
}
function load(sessionId) {
    try {
        const f = fileFor(sessionId);
        return fs.existsSync(f) ? JSON.parse(fs.readFileSync(f, 'utf8')) : {};
    } catch { return {}; }
}
function save(sessionId, data) {
    fs.writeFileSync(fileFor(sessionId), JSON.stringify(data, null, 2));
}

export async function isGroupBotEnabled(chatId, sessionId='main') {
    if (!chatId?.endsWith('@g.us')) return true;
    const data = load(sessionId);
    return data[chatId]?.enabled !== false;
}

export async function setGroupBotEnabled(chatId, enabled, sessionId='main') {
    if (!chatId?.endsWith('@g.us')) return false;
    const data = load(sessionId);
    data[chatId] = { enabled: !!enabled, updatedAt: Date.now() };
    save(sessionId, data);
    return true;
}
