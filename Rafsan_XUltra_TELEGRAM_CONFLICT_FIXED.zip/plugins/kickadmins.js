import { isOwnerOnly } from '../lib/isOwner.js';

export default {
    command: 'kickadmins',
    aliases: ['removeadmins'],
    category: 'admin',
    description: 'Remove other group admins (group-admin only)',
    usage: '.kickadmins',
    groupOnly: true,
    adminOnly: true,
    cooldown: 5000,
    async handler(sock, message, args, context) {
        const chatId = context.chatId;
        if (!context.isBotAdmin) {
            return sock.sendMessage(chatId, { text: '❌ *Make the bot an admin first.*' }, { quoted: message });
        }

        try {
            const metadata = await sock.groupMetadata(chatId);
            const participants = metadata.participants || [];
            const botId = (sock.decodeJid?.(sock.user?.id || '') || sock.user?.id || '').split(':')[0];
            const senderId = (context.senderId || message.key.participant || '').split(':')[0];

            const ownerNumber = String(context.config?.ownerNumber || '').replace(/\D/g, '');
            const targets = participants
                .filter(p => p.admin === 'admin' || p.admin === 'superadmin')
                .map(p => p.id)
                .filter(id => {
                    const clean = String(id).split(':')[0];
                    const number = clean.split('@')[0];
                    // Never remove the bot or the main bot owner.
                    return clean !== botId && number !== ownerNumber && clean !== senderId;
                });

            if (!targets.length) {
                return sock.sendMessage(chatId, {
                    text: 'ℹ️ *No removable admins found.*\n\nThe bot, main owner and the command user were protected.'
                }, { quoted: message });
            }

            // Admins must be demoted before they can be removed.
            const demoteResult = await sock.groupParticipantsUpdate(chatId, targets, 'demote');
            const demoted = Array.isArray(demoteResult)
                ? demoteResult.filter(r => String(r.status) === '200').length
                : targets.length;

            let removed = 0;
            if (demoted > 0) {
                const removeResult = await sock.groupParticipantsUpdate(chatId, targets, 'remove');
                removed = Array.isArray(removeResult)
                    ? removeResult.filter(r => String(r.status) === '200').length
                    : targets.length;
            }

            return sock.sendMessage(chatId, {
                text: `✅ *Kickadmins completed*\n\n👑 Admins targeted: ${targets.length}\n🔻 Demoted: ${demoted}\n🚫 Removed: ${removed}\n🛡️ Bot/Owner/You were protected.`
            }, { quoted: message });
        } catch (error) {
            console.error('Kickadmins error:', error);
            return sock.sendMessage(chatId, {
                text: `❌ *Kickadmins failed.*\n\n${error.message || 'Insufficient permissions.'}`
            }, { quoted: message });
        }
    }
};
