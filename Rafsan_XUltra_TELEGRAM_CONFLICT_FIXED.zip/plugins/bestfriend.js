import fs from 'fs';
import path from 'path';
const FILE=path.join(process.cwd(),'data','bestfriend-history.json');
function load(){try{return fs.existsSync(FILE)?JSON.parse(fs.readFileSync(FILE,'utf8')):{}}catch{return {}}}
function save(x){fs.mkdirSync(path.dirname(FILE),{recursive:true});fs.writeFileSync(FILE,JSON.stringify(x,null,2))}
export default {
 command:'bestfriend', aliases:['bff','friendship'], category:'fun',
 description:'Choose a different group member and send a friendly proposal',
 usage:'.bestfriend', groupOnly:true, cooldown:4000,
 async handler(sock,message,args,context){
  const chatId=context.chatId||message.key.remoteJid;
  const meta=await sock.groupMetadata(chatId);
  const me=sock.user?.id?.split(':')[0]+'@s.whatsapp.net';
  const sender=message.key.participant||message.key.remoteJid;
  const members=(meta.participants||[]).map(p=>p.id).filter(id=>id!==me&&id!==sender);
  if(!members.length)return sock.sendMessage(chatId,{text:'🥹 এই মুহূর্তে অন্য কোনো member পাওয়া গেল না।'},{quoted:message});
  const db=load(); const used=new Set(db[chatId]||[]);
  let available=members.filter(id=>!used.has(id));
  if(!available.length){available=members; db[chatId]=[];}
  const target=available[Math.floor(Math.random()*available.length)];
  db[chatId]=[...(db[chatId]||[]),target].slice(-members.length);
  save(db);
  const name=target.split('@')[0];
  const text=`╭━━〔 💙 BEST FRIEND PROPOSAL 〕━━╮\n┃\n┃ 👋 Hey @${name}!\n┃\n┃ আজ থেকে তুমি কি আমার\n┃ *BEST FRIEND* হবে? 🥹🤝\n┃\n┃ বন্ধুত্বে কোনো শর্ত নেই,\n┃ শুধু একটু loyalty আর অনেক হাসি! 😄✨\n┃\n╰━━━━━━━━━━━━━━━━━━━━╯`;
  return sock.sendMessage(chatId,{text,mentions:[target]},{quoted:message});
 }
};