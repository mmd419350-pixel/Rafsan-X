import store from '../lib/lightweight_store.js';
import isOwnerOrSudo from '../lib/isOwner.js';
import isAdmin from '../lib/isAdmin.js';

const configCache = new Map();
const CONFIG_TTL = 2500;
const linkPatterns = Object.freeze({
  whatsappGroup: /(?:https?:\/\/)?chat\.whatsapp\.com\/[A-Za-z0-9]{10,}/i,
  whatsappChannel: /(?:https?:\/\/)?wa\.me\/channel\/[A-Za-z0-9]{6,}/i,
  telegram: /(?:https?:\/\/)?(?:t\.me|telegram\.me)\/[A-Za-z0-9_+\-]+/i,
  allLinks: /(?:https?:\/\/|www\.)\S+|(?:[a-z0-9-]+\.)+[a-z]{2,}(?:\/\S*)?/i
});
const keyFor=(sock,chatId)=>`${sock?.sessionKey||'main'}::${chatId}`;
async function getCachedConfig(sock,chatId){
  const key=keyFor(sock,chatId), now=Date.now(), c=configCache.get(key);
  if(c && now-c.time<CONFIG_TTL) return c.value;
  const value=await store.getSetting(key,'antilink');
  configCache.set(key,{time:now,value:value||null}); return value||null;
}
function invalidateConfig(sock,chatId){configCache.delete(keyFor(sock,chatId));}
async function setAntilink(chatId,type,action,sock){
  const key=keyFor(sock,chatId); await store.saveSetting(key,'antilink',{enabled:true,action,type});
  invalidateConfig(sock,chatId); return true;
}
async function removeAntilink(chatId,_type,sock){
  const key=keyFor(sock,chatId); await store.saveSetting(key,'antilink',{enabled:false,action:null,type:null});
  invalidateConfig(sock,chatId); return true;
}
export async function handleLinkDetection(sock,chatId,message,userMessage,senderId){
  try{
    const config=await getCachedConfig(sock,chatId);
    if(!config?.enabled || !userMessage || !message?.key) return false;
    if(await isOwnerOrSudo(senderId,sock,chatId)) return false;
    const admin=await isAdmin(sock,chatId,senderId); if(admin.isSenderAdmin) return false;
    let linkType=null;
    if(linkPatterns.whatsappGroup.test(userMessage)) linkType='WhatsApp Group';
    else if(linkPatterns.whatsappChannel.test(userMessage)) linkType='WhatsApp Channel';
    else if(linkPatterns.telegram.test(userMessage)) linkType='Telegram';
    else if(linkPatterns.allLinks.test(userMessage)) linkType='Link';
    if(!linkType) return false;
    const action=config.action||'delete';
    const deleteKey={...message.key,remoteJid:chatId,participant:message.key.participant||senderId};
    try{ await sock.sendMessage(chatId,{delete:deleteKey}); }catch(e){ console.error('[AntiLink delete]',e?.message||e); return false; }
    if(action==='kick'){
      try{ await sock.groupParticipantsUpdate(chatId,[senderId],'remove'); }catch(e){ console.error('[AntiLink kick]',e?.message||e); }
    } else if(action==='warn'){
      await sock.sendMessage(chatId,{text:`🚫 @${senderId.split('@')[0]} link detected and deleted.`,mentions:[senderId]}).catch(()=>{});
    } else {
      await sock.sendMessage(chatId,{text:`🚫 @${senderId.split('@')[0]} — ${linkType} links are not allowed here.`,mentions:[senderId]}).catch(()=>{});
    }
    return true;
  }catch(e){console.error('[AntiLink]',e?.message||e); return false;}
}
export default {
 command:'antilink',aliases:['alink','linkblock'],category:'admin',
 description:'Fast group link protection',usage:'.antilink <on|off|set|status>',groupOnly:true,adminOnly:true,
 async handler(sock,message,args,context){
  const chatId=context.chatId||message.key.remoteJid, action=String(args[0]||'').toLowerCase();
  const config=await getCachedConfig(sock,chatId);
  if(!action)return sock.sendMessage(chatId,{text:`╭━━〔 🔗 ANTILINK 〕━━╮\n┃ Status: ${config?.enabled?'🟢 ON':'🔴 OFF'}\n┃ Action: ${config?.action||'delete'}\n╰━━━━━━━━━━━━━━━━━━╯\n\n• .antilink on\n• .antilink off\n• .antilink set delete\n• .antilink set kick\n• .antilink set warn\n• .antilink status`},{quoted:message});
  if(action==='on'){await setAntilink(chatId,'on','delete',sock);return sock.sendMessage(chatId,{text:'🟢 *ANTILINK ENABLED*'},{quoted:message});}
  if(action==='off'){await removeAntilink(chatId,'on',sock);return sock.sendMessage(chatId,{text:'🔴 *ANTILINK DISABLED*'},{quoted:message});}
  if(action==='set'){const a=String(args[1]||'').toLowerCase();if(!['delete','kick','warn'].includes(a))return sock.sendMessage(chatId,{text:'❌ Use `.antilink set delete|kick|warn`'},{quoted:message});await setAntilink(chatId,'on',a,sock);return sock.sendMessage(chatId,{text:`✅ *ANTILINK ACTION: ${a.toUpperCase()}*`},{quoted:message});}
  if(action==='status')return sock.sendMessage(chatId,{text:`🔗 *ANTILINK STATUS*\n\nStatus: ${config?.enabled?'🟢 ON':'🔴 OFF'}\nAction: ${config?.action||'delete'}`},{quoted:message});
  return sock.sendMessage(chatId,{text:'❌ Unknown option. Use `.antilink`.'},{quoted:message});
 }
};