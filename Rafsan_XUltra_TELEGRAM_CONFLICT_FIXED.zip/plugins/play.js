import yts from 'yt-search';
import { resolveYouTubeAudio, cleanFileName, downloadBuffer } from '../lib/mediaDownloaders.js';

export default {
  command: 'play', aliases: ['plays', 'music'], category: 'music',
  description: 'Search and download a song as MP3', usage: '.play <song name>', cooldown: 3000,
  async handler(sock, message, args, context) {
    const chatId = context.chatId || message.key.remoteJid;
    const query = args.join(' ').trim();
    if (!query) return sock.sendMessage(chatId, { text: '🎵 *PLAY*\n\nUsage: `.play <song name>`' }, { quoted: message });
    try {
      const result = await yts(query);
      const video = result?.videos?.[0];
      if (!video?.url) throw new Error('No matching song was found.');
      const audio = await resolveYouTubeAudio(video.url);
      const title = audio.title || video.title || query;
      const caption = `╭━━〔 🎶 NOW PLAYING 〕━━╮\n│ 🎧 *${title}*\n│ ⏱️ ${audio.duration || video.timestamp || 'Unknown'}\n│ 📥 MP3 • Ready\n╰━━━━━━━━━━━━━━━━━━━━╯`;
      if (audio.thumbnail || video.thumbnail) {
        try { await sock.sendMessage(chatId, { image: { url: audio.thumbnail || video.thumbnail }, caption }, { quoted: message }); }
        catch { await sock.sendMessage(chatId, { text: caption }, { quoted: message }); }
      } else await sock.sendMessage(chatId, { text: caption }, { quoted: message });
      try {
        await sock.sendMessage(chatId, { audio: { url: audio.url }, mimetype: 'audio/mpeg', fileName: audio.filename || `${cleanFileName(title)}.mp3`, ptt: false }, { quoted: message });
      } catch {
        const buffer = await downloadBuffer(audio.url, { maxContentLength: 55 * 1024 * 1024, maxBodyLength: 55 * 1024 * 1024 });
        await sock.sendMessage(chatId, { audio: buffer, mimetype: 'audio/mpeg', fileName: audio.filename || `${cleanFileName(title)}.mp3`, ptt: false }, { quoted: message });
      }
    } catch (error) {
      console.error('[PLAY]', error);
      await sock.sendMessage(chatId, { text: `❌ *Play failed.*\n\n${error?.message || 'Audio provider unavailable.'}` }, { quoted: message });
    }
  }
};
