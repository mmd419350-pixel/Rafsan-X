import config from '../config.js';
import commandHandler from '../lib/commandHandler.js';
import path from 'path';
import fs from 'fs';
import os from 'os';
import { getBotSettings, sessionMenuStatePath } from '../lib/sessionSettings.js';

const MENU_NEWSLETTER = {
    newsletterJid: '120363426733881060@newsletter',
    newsletterName: '𝙓𝙖𝙛𝙨𝙖𝙣 𝙓 𝙏𝙖𝙘𝙝',
    serverMessageId: -1
};

// IMPORTANT: this attribution is intentionally used only by .menu.
const MENU_CONTEXT_INFO = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: MENU_NEWSLETTER
};

const OWNER_NUMBER = '8801787638926';
const TELEGRAM_PAIR_LINK = config.telegramPairLink || '';

function formatTime() {
    return new Date().toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: true,
        timeZone: config.timeZone || 'Asia/Dhaka'
    });
}

function formatUptime(totalSeconds) {
    let s = Math.max(0, Math.floor(Number(totalSeconds) || 0));
    const d = Math.floor(s / 86400); s %= 86400;
    const h = Math.floor(s / 3600); s %= 3600;
    const m = Math.floor(s / 60); s %= 60;
    const parts = [];
    if (d) parts.push(`${d}d`);
    if (h) parts.push(`${h}h`);
    if (m) parts.push(`${m}m`);
    if (s || !parts.length) parts.push(`${s}s`);
    return parts.join(' ');
}

function systemInfo() {
    const total = os.totalmem() / 1024 / 1024;
    const free = os.freemem() / 1024 / 1024;
    const used = Math.max(0, total - free);
    const load = os.loadavg?.()[0] || 0;
    const cpuCount = os.cpus()?.length || 1;
    const cpuPercent = Math.min(100, Math.max(0, (load / cpuCount) * 100));
    return {
        ram: `${used.toFixed(0)}MB / ${total.toFixed(0)}MB`,
        cpu: `${cpuPercent.toFixed(1)}%`,
        uptime: formatUptime(process.uptime())
    };
}

function renderMenu(categories, prefix, info) {
    let t = `╭━━━〔 ⚡ 𝐑𝐀𝐅𝐒𝐀𝐍-𝐗𝐔𝐋𝐓𝐑𝐀 ⚡ 〕━━━╮\n`;
    t += `┃ 🟢 Status  : ONLINE & READY\n`;
    t += `┃ 💎 Version : ${info.version}\n`;
    t += `┃ 🧩 Plugins : ${info.total}\n`;
    t += `┃ 🔧 Prefix  : ${prefix}\n`;
    t += `┃ ⏱️ Uptime  : ${info.uptime}\n`;
    t += `┃ 🧠 CPU     : ${info.cpu}\n`;
    t += `┃ 💾 RAM     : ${info.ram}\n`;
    t += `╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯\n\n`;

    t += `╭──❍「 🔗 𝐂𝐎𝐍𝐍𝐄𝐂𝐓 」❍\n`;
    if (TELEGRAM_PAIR_LINK) t += `├• 🔐 Telegram Pair : ${TELEGRAM_PAIR_LINK}\n`;
    t += `├• 📞 Owner         : +${OWNER_NUMBER}\n`;
    t += `╰──────────────────────────────╯\n\n`;

    t += `╭──❍「 📚 𝐀𝐋𝐋 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐒 」❍\n`;
    for (const [category, commands] of categories) {
        if (!commands.length) continue;
        t += `│\n│ ✦ ${category.toUpperCase()}\n`;
        for (const cmd of commands) {
            // Every command gets its own line — no combined command pairs.
            t += `│  ${prefix}${cmd}\n`;
        }
    }
    t += `╰──────────────────────────────╯\n\n`;
    t += `╭━━〔 ✨ 𝐑𝐀𝐅𝐒𝐀𝐍-𝐗𝐔𝐋𝐓𝐑𝐀 〕━━╮\n`;
    t += `┃ 🚀 Fast • Smart • Stable\n`;
    t += `┃ 🛡️ Session Isolation : ON\n`;
    t += `┃ 🤖 ${info.total} Loaded Commands\n`;
    t += `┃ 🕒 ${info.time}\n`;
    t += `╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯`;
    return t;
}

export default {
    command: 'menu',
    aliases: ['help', 'commands', 'h', 'list'],
    category: 'general',
    description: 'Show all commands',
    usage: '.menu [command]',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const prefix = config.prefixes[0] || '.';
        const scopedSettings = getBotSettings(sock);
        const imagePath = scopedSettings.menuImage && fs.existsSync(scopedSettings.menuImage)
            ? scopedSettings.menuImage
            : path.join(process.cwd(), 'assets/thumb.png');
        const videoPath = scopedSettings.menuVideo && fs.existsSync(scopedSettings.menuVideo)
            ? scopedSettings.menuVideo
            : path.join(process.cwd(), 'assets/menu.mp4');
        const songPath = scopedSettings.menuSong && fs.existsSync(scopedSettings.menuSong)
            ? scopedSettings.menuSong
            : path.join(process.cwd(), 'assets/menu.mp3');

        if (args.length) {
            const searchTerm = args.join(' ').toLowerCase();
            let cmd = commandHandler.commands.get(searchTerm);
            if (!cmd && commandHandler.aliases.has(searchTerm)) {
                cmd = commandHandler.commands.get(commandHandler.aliases.get(searchTerm));
            }
            if (!cmd) {
                const first = args[0].toLowerCase();
                cmd = commandHandler.commands.get(first) || commandHandler.commands.get(commandHandler.aliases.get(first));
            }
            if (!cmd) {
                return sock.sendMessage(chatId, {
                    text: `❌ Command "${args.join(' ')}" not found.\n\nUse ${prefix}menu to see all commands.`
                }, { quoted: message });
            }
            const text = `╭━━━━━━━━━━━━━━⬣\n┃ 📌 *COMMAND INFO*\n┃\n┃ ⚡ *Command:* ${prefix}${cmd.command}\n┃ 📝 *Desc:* ${cmd.description || 'No description'}\n┃ 📖 *Usage:* ${cmd.usage || `${prefix}${cmd.command}`}\n┃ 🏷️ *Category:* ${cmd.category || 'misc'}\n┃ 🔖 *Aliases:* ${cmd.aliases?.length ? cmd.aliases.map(a => prefix + a).join(', ') : 'None'}\n╰━━━━━━━━━━━━━━⬣`;
            if (fs.existsSync(imagePath)) {
                return sock.sendMessage(chatId, {
                    image: { url: imagePath },
                    caption: text
                }, { quoted: message });
            }
            return sock.sendMessage(chatId, { text }, { quoted: message });
        }

        const sys = systemInfo();
        const categories = Array.from(commandHandler.categories.entries())
            .map(([name, commands]) => [name, [...commands].sort((a, b) => a.localeCompare(b))]);
        const menuText = renderMenu(categories, prefix, {
            version: config.version || '7.1.0',
            total: commandHandler.commands.size,
            uptime: sys.uptime,
            cpu: sys.cpu,
            ram: sys.ram,
            time: formatTime()
        });

        // IMAGE -> VIDEO -> IMAGE, independently per WhatsApp session.
        const stateFile = sessionMenuStatePath(sock);
        let state = { next: 'image' };
        try {
            if (fs.existsSync(stateFile)) state = { ...state, ...JSON.parse(fs.readFileSync(stateFile, 'utf8')) };
        } catch {}

        const mediaCaption = `${menuText}\n\n╭───────────────╮\n│ 🖼️ Menu Image / 🎬 Menu Video\n╰───────────────╯`;
        const sendOptions = { quoted: message };
        if (state.next !== 'video' && fs.existsSync(imagePath)) {
            await sock.sendMessage(chatId, {
                image: { url: imagePath },
                caption: mediaCaption,
                contextInfo: MENU_CONTEXT_INFO
            }, sendOptions);
            state.next = 'video';
        } else if (fs.existsSync(videoPath)) {
            await sock.sendMessage(chatId, {
                video: { url: videoPath },
                caption: mediaCaption,
                mimetype: 'video/mp4',
                gifPlayback: false,
                contextInfo: MENU_CONTEXT_INFO
            }, sendOptions);
            state.next = 'image';
        } else if (fs.existsSync(imagePath)) {
            await sock.sendMessage(chatId, {
                image: { url: imagePath },
                caption: mediaCaption,
                contextInfo: MENU_CONTEXT_INFO
            }, sendOptions);
            state.next = 'video';
        } else {
            await sock.sendMessage(chatId, { text: mediaCaption, contextInfo: MENU_CONTEXT_INFO }, sendOptions);
        }

        fs.writeFileSync(stateFile, JSON.stringify(state, null, 2));

        if (fs.existsSync(songPath)) {
            try {
                await sock.sendMessage(chatId, {
                    audio: { url: songPath },
                    mimetype: 'audio/mpeg',
                    fileName: 'Rafsan-XUltra-menu.mp3'
                }, sendOptions);
            } catch (error) {
                console.error('[MENU MP3]', error?.message || error);
            }
        }
    }
};
