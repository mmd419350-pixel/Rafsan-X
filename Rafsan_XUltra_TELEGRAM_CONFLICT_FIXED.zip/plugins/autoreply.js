import fs from 'fs';
import path from 'path';
import store, { getCurrentSessionKey } from '../lib/lightweight_store.js';
import { dataFile } from '../lib/paths.js';
import config from '../config.js';

const cache = new Map();
const TTL = 15000;
const defaultConfig = () => ({ enabled: false, replies: [] });

const BUILTIN_REPLIES = [
['হাই','হাই 😄 কেমন আছো?'],['হ্যালো','হ্যালো ভাই 👋 কী খবর?'],['hello','Hello 😄 কেমন চলছে?'],['hi','Hi 👋 বলো কী খবর?'],
['gm','Good morning 🌤️ দিনটা সুন্দর হোক!'],['good morning','Good morning ☀️ আজকের দিনটা awesome হোক!'],['gn','Good night 🌙 ভালো ঘুম হোক!'],['good night','Good night 😴 কাল আবার কথা হবে!'],
['কেমন আছো','আলহামদুলিল্লাহ ভালো আছি 😊 তুমি কেমন আছো?'],['kmn acho','Alhamdulillah valo achi 😌 tumi kmn acho?'],['ki obostha','Alhamdulillah chill 😎 tomar ki obostha?'],
['কি খবর','সব ঠিকঠাক 😄 তোমার খবর বলো!'],['খাইছো','হুম 😋 তুমি খাইছো?'],['khaiso','Hae 😋 tumi khaiso?'],['খাবার','খাবার দেখলেই mood ভালো হয়ে যায় 😂🍽️'],
['ভালোবাসি','ভালোবাসা সুন্দর জিনিস ❤️ তবে respect-টাই আগে।'],['love','Love is beautiful ❤️ keep it genuine.'],['miss you','Aww 😄 আমিও কথাটা মনে রাখলাম!'],['মিস করি','কথা বলতে থাকো, miss করার chance কমে যাবে 😄'],
['ধন্যবাদ','Welcome ভাই 🤝 সবসময়!'],['thanks','Anytime bro 🤝'],['sorry','No worries 😊 ভুল হতেই পারে।'],['সরি','কোনো সমস্যা নেই ভাই 😊'],
['bye','Bye 👋 ভালো থেকো!'],['বিদায়','আবার দেখা হবে ইনশাআল্লাহ 🌸'],['haha','হাহা 😂 হাসি থামিও না!'],['lol','LOL 😂'],
['sad','মন খারাপ হলে কথা বলো, একা থেকো না। 🌿'],['দুঃখ','মন খারাপ থাকলে একটু rest নাও 🌿'],['খুশি','এই তো চাই! 😄 Keep smiling!'],
['single','Single life 😎 শান্তি আছে, drama কম!'],['couple','Respect + trust = healthy bond ❤️'],['crush','Crush থাকতেই পারে 😄 আগে মানুষটাকে ভালোভাবে জানো।'],
['study','পড়াশোনা একটু একটু করে করলেই অনেক এগোনো যায় 📚'],['পড়াশোনা','আজ একটু পড়ো, কাল নিজের উপরই proud হবে 📚✨'],['exam','Exam আসলে panic না—plan করে পড়ো 💪📚'],['পরীক্ষা','শান্ত থাকো, যা পড়েছো সেটাই সুন্দর করে লিখো ✍️'],
['game','Game পরে হবে 😎 আগে কাজটা শেষ করো!'],['pubg','GG 😎 ভালো খেলো, fair play রাখো!'],['football','Football mood ⚽🔥'],['cricket','Cricket time 🏏🔥'],['music','Music mood fix করে দেয় 🎧✨'],['song','কোন vibe-এর গান চাই? 🎧'],['movie','Movie night? 🍿😄'],['anime','Anime vibe on 😎✨'],
['cute','Haha 😄 thanks!'],['beautiful','Nice compliment 😄'],['handsome','Haha bro, confidence রাখো 😎'],['কি করো','তোমাদের সাথেই আড্ডা দিচ্ছি 😄'],['ki koro','Tomader sathei adda dicchi 😄'],
['ঘুম','ঘুম দরকার 😴 শরীর-মন দুটোই refresh হবে।'],['ghum','Ghumao bro 😴 kal fresh thakba!'],['বোর','Bore lagle adda dao 😄'],['bore','Bore lagle kotha bolo 😄'],
['চা','চা time ☕😄'],['tea','Tea time ☕'],['coffee','Coffee mood ☕😎'],['কফি','Coffee ছাড়া coding চলে নাকি? 😂☕'],
['শুভ সকাল','শুভ সকাল 🌤️ দিনটা সুন্দর কাটুক!'],['শুভ রাত্রি','শুভ রাত্রি 🌙 শান্তিতে ঘুমাও!'],['আলহামদুলিল্লাহ','আলহামদুলিল্লাহ ❤️'],['ইনশাআল্লাহ','ইনশাআল্লাহ 🤲'],['mashallah','MashaAllah ❤️'],
['জাযাকাল্লাহ','ওয়া ইইয়্যাকুম 🤍'],['assalamualaikum','ওয়ালাইকুমুস সালাম 🌸'],['salam','ওয়ালাইকুমুস সালাম 🤍'],
['owner','Owner info দরকার হলে `.ownerinfo` ব্যবহার করো 👑'],['bot','Yes bro 😎 আমি online!'],['ping','🏓 Pong! Bot is alive ⚡'],['menu','Menu দেখতে `.menu` দাও 📋'],
['help','Help দরকার হলে `.menu` দিয়ে commands দেখে নাও 📚'],['admin','Admin matters? Group rules follow করো 👑'],['spam','Spam না করে chill করো 😄'],['sticker','Sticker mood 😂✨'],['good','Nice! 😄'],['nice','Thanks bro 🤝'],['wow','Wow indeed 😮✨'],
['😂','হাসি চলুক 😂'],['❤️','❤️ respect & good vibes!'],['😭','আরে 😅 কী হয়েছে?'],['😎','Style on 😎🔥'],['🔥','🔥 vibe detected!'],
]

const legacyPath = dataFile('autoreplies.json');

function cacheKey() { return getCurrentSessionKey(); }
async function initConfig() {
  const key = cacheKey();
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < TTL) return hit.value;
  let value = await store.getSetting('global', 'autoreplies');
  // One-time migration: preserve the existing 300+/custom replies while keeping ON/OFF session-scoped.
  if (!value) {
    try {
      const legacy = JSON.parse(fs.readFileSync(legacyPath, 'utf8'));
      if (legacy && Array.isArray(legacy.replies)) value = { enabled: false, replies: legacy.replies };
    } catch {}
  }
  value = value || defaultConfig();
  value.enabled = Boolean(value.enabled);
  value.replies = Array.isArray(value.replies) ? value.replies : [];
  const existing = new Set(value.replies.map(r => String(r?.trigger || '').toLowerCase()));
  for (const [trigger, response] of BUILTIN_REPLIES) {
    if (!existing.has(trigger.toLowerCase())) value.replies.push({ trigger: trigger.toLowerCase(), response, exactMatch: true, builtin: true });
  }
  cache.set(key, { value, at: Date.now() });
  return value;
}
async function saveConfig(value) {
  const normalized = { enabled: Boolean(value.enabled), replies: Array.isArray(value.replies) ? value.replies : [] };
  cache.set(cacheKey(), { value: normalized, at: Date.now() });
  await store.saveSetting('global', 'autoreplies', normalized);
  return normalized;
}
export async function handleAutoReply(sock, chatId, message, userMessage) {
  try {
    const text = String(userMessage || '').trim().toLowerCase();
    if (!text) return false;
    const prefixes = Array.isArray(config.prefixes) ? config.prefixes : [];
    if (prefixes.some(p => p && text.startsWith(String(p).toLowerCase()))) return false;
    const cfg = await initConfig();
    if (!cfg.enabled || !cfg.replies.length) return false;
    for (const reply of cfg.replies) {
      const trigger = String(reply?.trigger || '').trim().toLowerCase();
      if (!trigger) continue;
      const exact = reply.exactMatch !== false;
      const matched = exact ? text === trigger : (text === trigger || text.startsWith(trigger + ' ') || text.endsWith(' ' + trigger) || text.includes(' ' + trigger + ' '));
      if (!matched) continue;
      const response = String(reply.response || '').replace(/\{name\}/gi, message?.pushName || 'there');
      if (!response) return false;
      await sock.sendMessage(chatId, { text: response }, { quoted: message });
      return true;
    }
  } catch (e) { console.error('[AUTOREPLY]', e?.message || e); }
  return false;
}
export { initConfig, saveConfig };
export default {
  command:'autoreply', aliases:['ar','autorespond'], category:'owner', description:'Toggle session-scoped auto reply', usage:'.autoreply <on|off>', ownerOnly:true,
  async handler(sock,message,args,context){
    const chatId=context.chatId || message.key.remoteJid;
    try{
      const cfg=await initConfig(); const action=String(args[0]||'').toLowerCase();
      if(!action) return sock.sendMessage(chatId,{text:`╭━━〔 🤖 AUTO REPLY 〕━━╮\n┃ Status : ${cfg.enabled?'🟢 ON':'🔴 OFF'}\n┃ Replies: ${cfg.replies.length}\n┃ Session: ${getCurrentSessionKey()}\n╰━━━━━━━━━━━━━━━━━━━━╯\n\n• .autoreply on\n• .autoreply off`},{quoted:message});
      if(!['on','off','enable','disable'].includes(action)) return sock.sendMessage(chatId,{text:'❌ Use `.autoreply on` or `.autoreply off`.'},{quoted:message});
      cfg.enabled=['on','enable'].includes(action); await saveConfig(cfg);
      return sock.sendMessage(chatId,{text:`${cfg.enabled?'🟢':'🔴'} *AutoReply ${cfg.enabled?'enabled':'disabled'} for this session.*`},{quoted:message});
    }catch(e){ console.error('[AUTOREPLY CMD]',e); return sock.sendMessage(chatId,{text:'❌ AutoReply could not be updated. Please try again.'},{quoted:message}); }
  }, handleAutoReply, initConfig, saveConfig
};
