import fs from 'fs';
import path from 'path';
import { isMainOwner } from '../lib/isOwner.js';

const FILE = path.join(process.cwd(), 'data', 'ownerinfo.json');
const DEFAULTS = {
  name: 'Rafsan-X',
  age: 'Not set',
  className: 'Not set',
  district: 'Not set',
  favoriteColor: 'Black',
  relationship: 'Not set'
};

function load() {
  try {
    if (!fs.existsSync(FILE)) fs.writeFileSync(FILE, JSON.stringify(DEFAULTS, null, 2));
    return { ...DEFAULTS, ...JSON.parse(fs.readFileSync(FILE, 'utf8')) };
  } catch { return { ...DEFAULTS }; }
}
function save(d) {
  fs.mkdirSync(path.dirname(FILE), { recursive: true });
  fs.writeFileSync(FILE, JSON.stringify(d, null, 2));
}

export default {
  command: 'setownerinfo',
  aliases: ['setowner'],
  category: 'owner',
  description: 'Set owner information',
  usage: '.setownerinfo Name | Age | Class | District | Favorite Color | Relationship',
  strictOwnerOnly: true,
  cooldown: 1500,
  async handler(sock, message, args, context) {
    const chatId = context.chatId || message.key.remoteJid;
    const sender = context.senderId || message.key.participant || message.key.remoteJid;
    if (!message.key.fromMe && !(await isMainOwner(sender, sock, chatId))) {
      return sock.sendMessage(chatId, { text: '👑 Only the main owner can use this command.' }, { quoted: message });
    }

    const input = args.join(' ').trim();
    if (!input) {
      const d = load();
      return sock.sendMessage(chatId, {
        text: `╭━━〔 👑 OWNER INFO 〕━━╮
┃ 👤 Name : ${d.name}
┃ 🎂 Age : ${d.age}
┃ 🎓 Class : ${d.className}
┃ 📍 District : ${d.district}
┃ 🎨 Favorite Color : ${d.favoriteColor}
┃ 💔 Relationship : ${d.relationship}
╰━━━━━━━━━━━━━━━━━━━━━━╯

Use:
.setownerinfo Name | Age | Class | District | Favorite Color | Relationship`
      }, { quoted: message });
    }

    const parts = input.split('|').map(x => x.trim());
    if (parts.length < 6) {
      return sock.sendMessage(chatId, {
        text: '❌ Please provide all 6 fields separated by `|`.\n\nExample:\n.setownerinfo Rafsan-X | 19 years | 2nd year | Mymensingh | Black | Broken Heart'
      }, { quoted: message });
    }
    const d = {
      name: parts[0] || DEFAULTS.name,
      age: parts[1] || DEFAULTS.age,
      className: parts[2] || DEFAULTS.className,
      district: parts[3] || DEFAULTS.district,
      favoriteColor: parts[4] || DEFAULTS.favoriteColor,
      relationship: parts.slice(5).join(' | ') || DEFAULTS.relationship
    };
    save(d);
    return sock.sendMessage(chatId, { text: '✅ *Owner information updated successfully.*\n\nUse `.setownerinfo` without arguments to view it.' }, { quoted: message });
  }
};
