import fs from 'fs';
import path from 'path';
const INFO_FILE = path.join(process.cwd(), 'data', 'ownerinfo.json');
const DEFAULTS = { name: 'Rafsan-X', age: 'Not set', className: 'Not set', district: 'Not set', favoriteColor: 'Black', relationship: 'Not set' };
function loadInfo() { try { if (!fs.existsSync(INFO_FILE)) fs.writeFileSync(INFO_FILE, JSON.stringify(DEFAULTS, null, 2)); return { ...DEFAULTS, ...JSON.parse(fs.readFileSync(INFO_FILE, 'utf8')) }; } catch { return { ...DEFAULTS }; } }
export default {
    command: 'owner', aliases: ['creator', 'ownerinfo'], category: 'info', description: 'Show bot owner information', usage: '.owner',
    async handler(sock, message, _args, context) {
        const chatId = context.chatId || message.key.remoteJid; const cfg = context.config || {}; const d = loadInfo();
        const ownerNumber = String(cfg.ownerNumber || '').replace(/\D/g, '');
        const text = `╭━━━〔 👑 OWNER INFO 〕━━━╮\n┃\n┃ 👤 Name           : ${d.name}\n┃ 🎂 Age            : ${d.age}\n┃ 🎓 Class          : ${d.className}\n┃ 📍 District       : ${d.district}\n┃ 🎨 Favorite Color : ${d.favoriteColor}\n┃ 💔 Relationship   : ${d.relationship}\n┃\n┃ 🤖 Bot            : ${cfg.botName || 'Rafsan-X'}\n┃ ⚙️ Version        : ${cfg.version || '6.0.0'}\n╰━━━━━━━━━━━━━━━━━━━━━━╯`;
        try {
            await sock.sendMessage(chatId, { text }, { quoted: message });
            if (ownerNumber) {
                const vcard = `BEGIN:VCARD\nVERSION:3.0\nFN:${d.name}\nTEL;waid=${ownerNumber}:${ownerNumber}\nEND:VCARD`;
                await sock.sendMessage(chatId, { contacts: { displayName: d.name, contacts: [{ vcard }] } }, { quoted: message });
            }
        } catch (e) { await sock.sendMessage(chatId, { text }, { quoted: message }).catch(() => {}); }
    }
};
