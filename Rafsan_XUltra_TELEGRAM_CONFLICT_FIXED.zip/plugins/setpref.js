import fs from 'fs';
import path from 'path';
import config from '../config.js';
const FILE=path.join(process.cwd(),'data','prefix.json');
function save(prefixes){fs.mkdirSync(path.dirname(FILE),{recursive:true});fs.writeFileSync(FILE,JSON.stringify({prefixes},null,2));}
function normalize(value){return [...new Set(value.split(',').map(x=>x.trim()).filter(x=>x.length>0&&x.length<=3&&/^[^\p{L}\p{N}\s]+$/u.test(x)))];}
export default {
 command:'setpref', aliases:['setprefix','prefix'], category:'owner',
 description:'Change bot command prefix', usage:'.setpref . | / | !', strictOwnerOnly:true, cooldown:2000,
 async handler(sock,message,args,context){
  const chatId=context.chatId||message.key.remoteJid;
  const raw=args.join(' ').trim();
  if(!raw)return sock.sendMessage(chatId,{text:`⚙️ *PREFIX SETTINGS*\n\nCurrent: ${config.prefixes.join(', ')}\n\nUsage:\n.setpref .\n.setpref !,.\n\n⚠️ Use 1–3 punctuation characters only.`},{quoted:message});
  const prefixes=normalize(raw);
  if(!prefixes.length)return sock.sendMessage(chatId,{text:'❌ Invalid prefix. Example: `.setpref !`'},{quoted:message});
  config.prefixes=prefixes; config.prefix=prefixes[0];
  save(prefixes);
  return sock.sendMessage(chatId,{text:`✅ *Prefix updated successfully!*\n\nNew Prefix: ${prefixes.join('  ')}\n\nBot commands now use the new prefix.`},{quoted:message});
 }
};