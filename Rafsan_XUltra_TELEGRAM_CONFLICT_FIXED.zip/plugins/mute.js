export default {
    command: 'mute', aliases: ['silence'], category: 'admin', description: 'Mute the group for a specified duration', usage: '.mute [duration in minutes]', groupOnly: true, adminOnly: true,
    async handler(sock, message, args, context) {
        const { chatId, channelInfo } = context;
        const minutes = args[0] ? parseInt(args[0], 10) : undefined;
        try {
            await sock.groupSettingUpdate(chatId, 'announcement');
            if (minutes && minutes > 0) {
                await sock.sendMessage(chatId, { text: `🔇 *GROUP MUTED*\n\n👑 শুধু admins message দিতে পারবেন।\n⏱️ Duration: *${minutes} minutes*`, ...channelInfo }, { quoted: message });
                setTimeout(async () => { try { await sock.groupSettingUpdate(chatId, 'not_announcement'); await sock.sendMessage(chatId, { text: '🔊 *GROUP UNMUTED*\n\nসবাই আবার message করতে পারবেন ❤️', ...channelInfo }); } catch (e) { console.error('Auto-unmute error:', e.message); } }, minutes * 60 * 1000);
            } else {
                await sock.sendMessage(chatId, { text: '🔇 *GROUP MUTED*\n\nশুধু admins message দিতে পারবেন।', ...channelInfo }, { quoted: message });
            }
        } catch (error) {
            console.error('Mute error:', error);
            await sock.sendMessage(chatId, { text: '❌ Failed to mute the group. Make sure the bot is admin.', ...channelInfo }, { quoted: message });
        }
    }
};
