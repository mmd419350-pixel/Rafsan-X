function commandHandlerCount() {
    return commandHandler.commands.size || 0;
}

import commandHandler from '../lib/commandHandler.js';

export default {
    command: 'bot',
    aliases: [],
    category: 'general',
    description: 'Show the bot activation and quick-start information',
    usage: '.bot',
    isPrefixless: true,
    cooldown: 1000,
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const sessionNumber = String(sock?.sessionKey || sock?.user?.id || '').replace(/[^0-9]/g, '') || 'Unknown';
        const botName = context?.config?.botName || 'Rafsan-XUltra';
        const now = new Date().toLocaleString('en-US', {
            timeZone: 'Asia/Dhaka',
            year: 'numeric', month: '2-digit', day: '2-digit',
            hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true
        });
        const text = `╭──❍「 *BOT ACTIVATED* 」❍
├• 📅 ${now}
├• ✅ Status: ONLINE & READY
├• 💻 Version: ${context?.config?.version || '7.1.0'}
├• 👤 Owner: ${context?.config?.botOwner || 'Rafsan-XUltra'}
├• 📞 Contact: ${context?.config?.ownerNumber || '8801787638926'}
├• 🌐 Prefix: ${context?.config?.prefixes?.join(', ') || '.'}
├• 💻 Mode: ${context?.config?.commandMode || 'PUBLIC'} 🌐
├• 💡 ${commandHandlerCount(context)} Commands
╰─┬─★─☆─♪♪─❍
╭─┴❍「 *QUICK START* 」❍
◈ • .menu - All commands
◈ • .help - Bot guide
◈ • .owner - Contact owner
◈ • .settings - Settings
◈ • .ping - Check speed
◈ • .update - Update bot
╰─┬─★─☆─♪♪─❍
╭─┴❍「 *CONNECT* 」❍
◈ • 🔐 Telegram Pair Group
◈ • 📞 Owner: +8801787638926
╰───★─☆─♪♪─❍

🔐 *Telegram Pair:* https://t.me/+PGq0pf-gsVtkZGZl

🤖 ${botName} • Private Session Ready`;
        await sock.sendMessage(chatId, { text }, { quoted: message });
    }
};
