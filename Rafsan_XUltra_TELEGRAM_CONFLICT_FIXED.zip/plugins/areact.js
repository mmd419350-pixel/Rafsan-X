import store, { getCurrentSessionKey } from '../lib/lightweight_store.js';

const AUTO_EMOJIS = ['❤️','😂','🔥','😍','😎','👏','💯','🥰','😮','✨','👍','🤝','💖','🤣','🎉','🌸','🫶','😅'];
const state = new Map();

function sessionKey(sock) { return String(sock?.sessionKey || getCurrentSessionKey() || 'main'); }
async function getEnabled(sock) {
  const sid = sessionKey(sock);
  if (state.has(sid)) return state.get(sid);
  const saved = await store.getSetting(sid, 'autoReaction').catch(() => null);
  const enabled = Boolean(saved?.enabled ?? saved);
  state.set(sid, enabled);
  return enabled;
}
export async function setAutoReaction(sock, enabled) {
  const sid = sessionKey(sock);
  state.set(sid, Boolean(enabled));
  await store.saveSetting(sid, 'autoReaction', { enabled: Boolean(enabled) });
}
export async function handleAutoReaction(sock, message) {
  try {
    if (!message?.message || message.key?.fromMe) return false;
    if (!(await getEnabled(sock))) return false;
    const jid = message.key?.remoteJid;
    if (!jid || jid === 'status@broadcast') return false;
    const text = message.message?.conversation || message.message?.extendedTextMessage?.text || message.message?.imageMessage?.caption || message.message?.videoMessage?.caption || '';
    if (/^[!#.$%^&*+=?<>]/.test(String(text).trim())) return false;
    await sock.sendMessage(jid, { react: { text: AUTO_EMOJIS[Math.floor(Math.random() * AUTO_EMOJIS.length)], key: message.key } });
    return true;
  } catch (e) {
    console.error('[AUTOREACT]', e?.message || e);
    return false;
  }
}

export default {
  command: 'autoreact', aliases: ['areact'], category: 'owner',
  description: 'Session-scoped automatic reactions', usage: '.autoreact on/off', ownerOnly: true,
  async handler(sock, message, args, context) {
    const { chatId, channelInfo } = context;
    const action = String(args[0] || '').toLowerCase();
    if (!['on','off'].includes(action)) {
      return sock.sendMessage(chatId, { text: '╭━━〔 🤖 AUTO REACT 〕━━╮\n┃ Usage: .autoreact on/off\n┃ Scope: This session only\n╰━━━━━━━━━━━━━━━━━━━━╯', ...channelInfo }, { quoted: message });
    }
    await setAutoReaction(sock, action === 'on');
    return sock.sendMessage(chatId, { text: action === 'on' ? '🟢 *AutoReact ON*\n⚡ This session will react to incoming messages.' : '🔴 *AutoReact OFF*\n🛑 Reactions stopped for this session.', ...channelInfo }, { quoted: message });
  },
  handleAutoReaction,
  setAutoReaction
};
