import { isMainOwner } from '../lib/isOwner.js';

export default {
    command: 'kickall',
    aliases: ['removeall'],
    category: 'admin',
    description: 'Owner-only: remove all non-admin members from the group',
    usage: '.kickall',
    groupOnly: true,
    adminOnly: true,
    strictOwnerOnly: true,
    cooldown: 5000,
    async handler(sock, message, args, context) {
        const chatId = context.chatId;
        const senderId = context.senderId || message?.key?.participant || message?.key?.remoteJid;
        if (!message.key?.fromMe && !(await isMainOwner(senderId, sock, chatId))) {
            return sock.sendMessage(chatId, { text: '👑 *Only the bot owner can use .kickall.*' }, { quoted: message });
        }
        if (!context.isBotAdmin) {
            return sock.sendMessage(chatId, {
                text: '❌ *Make the bot an admin first.*'
            }, { quoted: message });
        }

        try {
            const metadata = await sock.groupMetadata(chatId);
            const participants = metadata.participants || [];
            const admins = participants.filter(p => p.admin === 'admin' || p.admin === 'superadmin');
            const adminIds = new Set(admins.map(p => p.id));
            const botId = sock.decodeJid?.(sock.user?.id || '') || sock.user?.id || '';

            const targets = participants
                .map(p => p.id)
                .filter(id => id && id !== botId && !adminIds.has(id));

            if (!targets.length) {
                return sock.sendMessage(chatId, {
                    text: 'ℹ️ *Nothing to remove.*\n\nAll removable members are already absent or are admins.'
                }, { quoted: message });
            }

            await sock.sendMessage(chatId, {
                text: `⚠️ *Kickall started*\n\nRemoving ${targets.length} non-admin member(s)...`
            }, { quoted: message });

            // Small batches reduce rate-limit pressure and make failures easier to recover from.
            const batchSize = 5;
            let removed = 0;
            let failed = 0;
            for (let i = 0; i < targets.length; i += batchSize) {
                const batch = targets.slice(i, i + batchSize);
                try {
                    const result = await sock.groupParticipantsUpdate(chatId, batch, 'remove');
                    if (Array.isArray(result)) {
                        removed += result.filter(r => r.status === '200' || r.status === 200).length || batch.length;
                    } else {
                        removed += batch.length;
                    }
                } catch (err) {
                    failed += batch.length;
                    console.error('Kickall batch error:', err.message);
                }
                if (i + batchSize < targets.length) {
                    await new Promise(resolve => setTimeout(resolve, 500));
                }
            }

            return sock.sendMessage(chatId, {
                text: `✅ *Kickall finished*\n\n👥 Targeted: ${targets.length}\n🚫 Removed: ${removed}\n⚠️ Failed: ${failed}\n\n_Admins and the bot were kept safe._`
            }, { quoted: message });
        } catch (error) {
            console.error('Kickall error:', error);
            return sock.sendMessage(chatId, {
                text: `❌ *Kickall failed*\n\n${error.message || 'Unknown error'}`
            }, { quoted: message });
        }
    }
};
