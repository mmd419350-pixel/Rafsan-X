import config from '../config.js';
import CommandHandler from '../lib/commandHandler.js';
import fs from 'fs';
import path from 'path';
import { getBotSettings, sessionMenuStatePath } from '../lib/sessionSettings.js';
const menuEmojis = ['✨', '🌟', '⭐', '💫', '🎯', '🎨', '🎪', '🎭'];
const activeEmojis = ['✅', '🟢', '💚', '✔️', '☑️'];
const disabledEmojis = ['❌', '🔴', '⛔', '🚫', '❎'];
const fastEmojis = ['⚡', '🚀', '💨', '⏱️', '🔥'];
const slowEmojis = ['🐢', '🐌', '⏳', '⌛', '🕐'];
const categoryEmojis = {
    general: ['📱', '🔧', '⚙️', '🛠️'],
    owner: ['👑', '🔱', '💎', '🎖️'],
    admin: ['🛡️', '⚔️', '🔐', '👮'],
    group: ['👥', '👫', '🧑‍🤝‍🧑', '👨‍👩‍👧‍👦'],
    download: ['📥', '⬇️', '💾', '📦'],
    ai: ['🤖', '🧠', '💭', '🎯'],
    search: ['🔍', '🔎', '🕵️', '📡'],
    apks: ['📲', '📦', '💿', '🗂️'],
    info: ['ℹ️', '📋', '📊', '📄'],
    fun: ['🎮', '🎲', '🎰', '🎪'],
    stalk: ['👀', '🔭', '🕵️', '🎯'],
    games: ['🎮', '🕹️', '🎯', '🏆'],
    images: ['🖼️', '📸', '🎨', '🌄'],
    menu: ['📜', '📋', '📑', '📚'],
    tools: ['🔨', '🔧', '⚡', '🛠️'],
    stickers: ['🎭', '😀', '🎨', '🖼️'],
    quotes: ['💬', '📖', '✍️', '💭'],
    music: ['🎵', '🎶', '🎧', '🎤'],
    utility: ['📂', '🔧', '⚙️', '🛠️']
};
function getRandomEmoji(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
}
function getCategoryEmoji(category) {
    const emojis = categoryEmojis[category.toLowerCase()] || ['📂', '📁', '🗂️', '📋'];
    return getRandomEmoji(emojis);
}
function formatTime() {
    const now = new Date();
    const options = {
        hour: '2-digit',
        minute: '2-digit',
        hour12: false,
        timeZone: config.timeZone || 'UTC'
    };
    return now.toLocaleTimeString('en-US', options);
}
export default {
    command: 'smenu',
    aliases: ['shelp', 'smart', 'help2'],
    category: 'general',
    description: 'Interactive smart menu with live status',
    usage: '.smenu',
    isPrefixless: true,
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        try {
            const scopedSettings = getBotSettings(sock);
            const imagePath = scopedSettings.menuImage && fs.existsSync(scopedSettings.menuImage) ? scopedSettings.menuImage : path.join(process.cwd(), 'assets/thumb.png');
            const videoPath = scopedSettings.menuVideo && fs.existsSync(scopedSettings.menuVideo) ? scopedSettings.menuVideo : path.join(process.cwd(), 'assets/menu.mp4');
            const thumbnail = fs.existsSync(imagePath) ? fs.readFileSync(imagePath) : null;
            const categories = Array.from(CommandHandler.categories.keys());
            const stats = CommandHandler.getDiagnostics();
            const menuEmoji = getRandomEmoji(menuEmojis);
            const activeEmoji = getRandomEmoji(activeEmojis);
            const disabledEmoji = getRandomEmoji(disabledEmojis);
            const fastEmoji = getRandomEmoji(fastEmojis);
            const slowEmoji = getRandomEmoji(slowEmojis);
            let menuText = `╔═━❰ 🤖 ${config.botName || 'Rafsan-X'} 🤖 ❱━═╗\n`;
            menuText += `┃ 🚀 Premium Command Center\n`;
            menuText += `╚════════════════════════════╝\n\n`;
            menuText += `┏━━━━━━━━━━━━━━━━┓\n`;
            menuText += `┃ 📱 *Bot:* ${config.botName || 'Rafsan-X'}\n`;
            menuText += `┃ 🔖 *Version:* ${config.version || '7.1.0'}\n`;
            menuText += `┃ 👤 *Owner:* ${config.botOwner || 'Unknown'}\n`;
            menuText += `┃ ⏰ *Time:* ${formatTime()}\n`;
            menuText += `┃ ℹ️ *Prefix:* ${config.prefixes ? config.prefixes.join(', ') : '.'}\n`;
            menuText += `┃ 📊 *Plugins:* ${CommandHandler.commands.size}\n`;
            menuText += `┗━━━━━━━━━━━━━━━━┛\n\n`;
            const topCmds = stats.slice(0, 3).filter(s => s.usage > 0);
            if (topCmds.length > 0) {
                menuText += `🔥 *TOP COMMANDS:*\n`;
                topCmds.forEach((c, i) => {
                    const rank = i === 0 ? '🥇' : i === 1 ? '🥈' : '🥉';
                    menuText += `${rank} .${c.command} • ${c.usage} uses\n`;
                });
                menuText += `\n`;
            }
            for (const cat of categories) {
                const catEmoji = getCategoryEmoji(cat);
                menuText += `╭━━〔 ${catEmoji} ${cat.toUpperCase()} 〕━━⬣\n`;
                const catCmds = CommandHandler.getCommandsByCategory(cat);
                catCmds.forEach((cmdName, index) => {
                    const isLast = index === catCmds.length - 1;
                    const prefix = isLast ? '└' : '├';
                    const isOff = CommandHandler.disabledCommands.has(cmdName.toLowerCase());
                    const cmdStats = stats.find(s => s.command === cmdName.toLowerCase());
                    const statusIcon = isOff ? disabledEmoji : activeEmoji;
                    let speedTag = '';
                    if (cmdStats && !isOff) {
                        const ms = parseFloat(cmdStats.average_speed);
                        if (ms > 0 && ms < 100)
                            speedTag = ` ${fastEmoji}`;
                        else if (ms > 1000)
                            speedTag = ` ${slowEmoji}`;
                    }
                    menuText += `${prefix}─ ${statusIcon} .${cmdName}${speedTag}\n`;
                });
                menuText += `\n`;
            }
            menuText += `━━━━━━━━━━━━━━━━━━━━━━\n`;
            menuText += `├  💡 *LEGEND*\n`;
            menuText += `├─ ${activeEmoji} Active Command\n`;
            menuText += `├─ ${disabledEmoji} Disabled Command\n`;
            menuText += `├─ ${fastEmoji} Fast Response\n`;
            menuText += `├─ ${slowEmoji} Slow Response\n`;
            menuText += `⁠└────────────────`;
            const contextInfo = {};
            const stateFile = sessionMenuStatePath(sock);
            let mediaState = { next: 'image' };
            try { if (fs.existsSync(stateFile)) mediaState = { ...mediaState, ...JSON.parse(fs.readFileSync(stateFile, 'utf8')) }; } catch {}
            const divider = '\n╭──────── MENU MEDIA ────────╮\n│  🖼️ IMAGE  │  🎬 VIDEO  │\n╰────────────────────────────╯\n';
            let messageOptions;
            if (mediaState.next !== 'video' && thumbnail) {
                messageOptions = { image: thumbnail, caption: menuText + divider + '🖼️ *Current:* MENU IMAGE', contextInfo };
                mediaState.next = 'video';
            } else if (fs.existsSync(videoPath)) {
                messageOptions = { video: { url: videoPath }, caption: menuText + divider + '🎬 *Current:* MENU VIDEO', mimetype: 'video/mp4', gifPlayback: false, contextInfo };
                mediaState.next = 'image';
            } else if (thumbnail) {
                messageOptions = { image: thumbnail, caption: menuText + divider + '🖼️ *Current:* MENU IMAGE', contextInfo };
                mediaState.next = 'video';
            } else {
                messageOptions = { text: menuText + divider, contextInfo };
            }
            fs.writeFileSync(stateFile, JSON.stringify(mediaState, null, 2));
            await sock.sendMessage(chatId, messageOptions, { quoted: message });
        }
        catch (error) {
            console.error('Menu Error:', error);
            await sock.sendMessage(chatId, {
                text: `❌ *Menu Error*\n\n${error.message}`
            }, { quoted: message });
        }
    }
};
