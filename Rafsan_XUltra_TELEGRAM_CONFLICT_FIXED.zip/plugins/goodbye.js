import { handleGoodbye } from '../lib/welcome.js';
import { isGoodByeOn, getGoodbye } from '../lib/index.js';
import { resolveParticipantMention } from '../lib/participantMention.js';

async function handleLeaveEvent(sock, id, participants) {
    if (!(await isGoodByeOn(id))) return;
    const customMessage = await getGoodbye(id);
    const groupMetadata = await sock.groupMetadata(id);
    const groupName = groupMetadata.subject || 'Our Group';
    const memberCount = groupMetadata.participants?.length || 0;

    for (const participant of participants || []) {
        try {
            const { mentionJid, displayName } = await resolveParticipantMention(sock, groupMetadata, participant);
            if (!mentionJid) {
                console.warn('[GOODBYE] Could not resolve a mention target; skipping this participant.');
                continue;
            }
            const mentionText = `@${displayName}`;
            const finalMessage = customMessage
                ? customMessage
                    .replace(/{user}/g, mentionText)
                    .replace(/{group}/g, groupName)
                    .replace(/{count}/g, String(memberCount))
                : `╭━━〔 🥀 𝐆𝐎𝐎𝐃𝐁𝐘𝐄 / 𝐁𝐈𝐃𝐀𝐘 🥀 〕━━╮
┃ 👤 Member : ${mentionText}
┃ 👥 Members now : ${memberCount}
┃ 🏠 Group : ${groupName}
╰━━━━━━━━━━━━━━━━━━━━╯

💔 *We'll miss you, ${mentionText}.*
🌙 তোমার হাসি, adda আর memories সত্যিই miss করবো।
🤲 *Take care, stay safe & stay blessed.*
🚪 *ফিরে আসতে চাইলে door সবসময় open থাকবে.*

🤖 *Rafsan-XUltra • Premium Group Assistant*`;
            await sock.sendMessage(id, { text: finalMessage, mentions: [mentionJid] });
        } catch (error) {
            console.error('[GOODBYE]', error);
        }
    }
}

export default {
    command: 'goodbye',
    aliases: ['bye', 'leave'],
    category: 'admin',
    description: 'Configure goodbye messages for leaving members',
    usage: '.goodbye <on|off|set message>',
    groupOnly: true,
    adminOnly: true,
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        await handleGoodbye(sock, chatId, message, args.join(' '));
    },
    handleLeaveEvent
};
