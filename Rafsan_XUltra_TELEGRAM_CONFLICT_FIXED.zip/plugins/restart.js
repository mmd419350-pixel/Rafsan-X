import { spawn } from 'child_process';
import fs from 'fs';
import { isMainOwner } from '../lib/isOwner.js';

export default {
  command: 'restart',
  aliases: ['reboot'],
  category: 'owner',
  description: 'Restart the bot process',
  usage: '.restart',
  strictOwnerOnly: true,
  cooldown: 5000,
  async handler(sock, message, args, context) {
    const chatId = context.chatId || message.key.remoteJid;
    const senderId = context.senderId || message.key.participant || message.key.remoteJid;
    if (!message.key.fromMe && !(await isMainOwner(senderId, sock, chatId))) {
      return sock.sendMessage(chatId, { text: '👑 Only the main bot owner can restart the bot.' }, { quoted: message });
    }
    await sock.sendMessage(chatId, {
      text: '♻️ *RESTARTING BOT...*\n\nPlease wait a few seconds. The panel/process manager should bring it back online automatically.'
    }, { quoted: message });
    setTimeout(() => {
      // In Docker/Katabump, exiting is the reliable restart signal for the panel daemon.
      if (process.env.KATABUMP || process.env.DOCKER || fs.existsSync('/.dockerenv')) {
        process.exit(0);
        return;
      }
      try {
        const child = spawn(process.execPath, process.argv.slice(1), {
          detached: true, stdio: 'ignore', cwd: process.cwd(), env: process.env
        });
        child.unref();
      } finally {
        process.exit(0);
      }
    }, 1200);
  }
};
