export default {
  command: 'flart',
  aliases: ['flirt', 'funcompliment'],
  category: 'fun',
  description: 'Send a playful Bangla compliment',
  usage: '.flart',
  cooldown: 2500,
  async handler(sock, message, args, context) {
    const chatId = context.chatId || message.key.remoteJid;
    const msgs = [
      '😄 আজকে তোমার vibe একদম premium!\n✨ হাসিটা keep করে রাখো—group-এর mood এমনিতেই ভালো হয়ে যায়।',
      '😂 এত সুন্দর attitude নিয়ে ঘুরো কীভাবে?\n🌟 তোমার presence মানেই একটু extra fun!',
      '😎 Warning! তোমার confidence দেখে group-এর Wi‑Fi-ও jealous হয়ে গেছে! 😂',
      '🌸 Simple compliment: তুমি আজকে বেশ cool দেখাচ্ছো—এভাবেই positive থাকো! ✨'
    ];
    return sock.sendMessage(chatId, { text: msgs[Math.floor(Math.random() * msgs.length)] }, { quoted: message });
  }
};
