import { resolveInstagram, downloadBuffer } from '../lib/mediaDownloaders.js';

export default {
  command: 'instagram', aliases: ['ig', 'igdl', 'insta'], category: 'download',
  description: 'Download Instagram posts, reels and videos', usage: '.ig <Instagram link>', cooldown: 3000,
  async handler(sock, message, args, context) {
    const chatId = context.chatId || message.key.remoteJid;
    const url = args.join(' ').trim();
    if (!url) return sock.sendMessage(chatId, { text: '📸 *INSTAGRAM DOWNLOADER*\n\nUsage: `.ig <Instagram link>`' }, { quoted: message });
    if (!/https?:\/\/(?:www\.)?(instagram\.com|instagr\.am)\//i.test(url)) return sock.sendMessage(chatId, { text: '❌ Please send a valid Instagram post/reel link.' }, { quoted: message });
    try {
      await sock.sendMessage(chatId, { react: { text: '🔄', key: message.key } });
      const mediaList = await resolveInstagram(url);
      for (let i = 0; i < mediaList.length; i++) {
        const media = mediaList[i];
        const caption = `📥 *Instagram Downloader*\n\n${media.type === 'video' ? '🎬 Video' : '🖼️ Image'}\n⚡ *Rafsan-XUltra*`;
        try {
          if (media.type === 'video') await sock.sendMessage(chatId, { video: { url: media.url }, mimetype: 'video/mp4', caption }, { quoted: message });
          else await sock.sendMessage(chatId, { image: { url: media.url }, caption }, { quoted: message });
        } catch (directError) {
          console.error('[INSTAGRAM] direct send failed:', directError.message);
          const buffer = await downloadBuffer(media.url, { maxContentLength: 90 * 1024 * 1024, maxBodyLength: 90 * 1024 * 1024, headers: { Referer: 'https://www.instagram.com/' } });
          if (media.type === 'video') await sock.sendMessage(chatId, { video: buffer, mimetype: 'video/mp4', caption }, { quoted: message });
          else await sock.sendMessage(chatId, { image: buffer, caption }, { quoted: message });
        }
      }
    } catch (error) {
      console.error('[INSTAGRAM]', error);
      await sock.sendMessage(chatId, { text: `❌ *Instagram download failed.*\n\n${error?.message || 'The media provider failed.'}` }, { quoted: message });
    }
  }
};
