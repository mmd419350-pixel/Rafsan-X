import { downloadContentFromMessage } from '@whiskeysockets/baileys';

function unwrapMessage(message) {
    let m = message?.message || message || {};
    for (let i = 0; i < 6 && m; i++) {
        if (m.imageMessage || m.videoMessage || m.audioMessage || m.documentMessage || m.stickerMessage || m.conversation || m.extendedTextMessage) return m;
        if (m.ephemeralMessage?.message) { m = m.ephemeralMessage.message; continue; }
        if (m.viewOnceMessage?.message) { m = m.viewOnceMessage.message; continue; }
        if (m.viewOnceMessageV2?.message) { m = m.viewOnceMessageV2.message; continue; }
        break;
    }
    return m || {};
}

async function mediaBuffer(mediaMessage, type) {
    const stream = await downloadContentFromMessage(mediaMessage, type);
    const chunks = [];
    for await (const chunk of stream) chunks.push(chunk);
    return Buffer.concat(chunks);
}

async function sendGroupStatus(sock, jid, payload) {
    const attempts = [
        { groupStatusMessage: payload },
        { groupStatusMessageV2: payload },
        // Supported by several Baileys-compatible builds that expose groupStatus as a wrapper.
        { ...payload, groupStatus: true }
    ];
    let lastError;
    for (const content of attempts) {
        try {
            return await sock.sendMessage(jid, content);
        } catch (error) {
            lastError = error;
        }
    }
    throw lastError || new Error('This Baileys build does not support Group Status.');
}

export default {
    command: 'groupstatus',
    aliases: ['gstatus'],
    category: 'group',
    description: 'Post a text/photo/video Group Status or show group information',
    usage: '.groupstatus text <message> | reply to photo/video with .groupstatus | .groupstatus info',
    groupOnly: true,
    cooldown: 3000,
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const sub = (args[0] || '').toLowerCase();

        if (sub === 'info') {
            try {
                const metadata = await sock.groupMetadata(chatId);
                const participants = metadata.participants || [];
                const admins = participants.filter(p => p.admin === 'admin' || p.admin === 'superadmin').length;
                return sock.sendMessage(chatId, {
                    text: `╭━━〔 📊 GROUP STATUS 〕━━╮\n┃ 👥 *Name:* ${metadata.subject || 'Unknown'}\n┃ 🆔 *Members:* ${participants.length}\n┃ 👑 *Admins:* ${admins}\n┃ 🤖 *Bot:* ${context.isBotAdmin ? 'Admin ✅' : 'Member ❌'}\n╰━━━━━━━━━━━━━━━━━━━━╯`
                }, { quoted: message });
            } catch (error) {
                return sock.sendMessage(chatId, { text: `❌ Group info failed: ${error.message}` }, { quoted: message });
            }
        }

        try {
            const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            const source = quoted || message.message;
            const media = unwrapMessage(source);

            if (media.imageMessage) {
                const buffer = await mediaBuffer(media.imageMessage, 'image');
                await sendGroupStatus(sock, chatId, {
                    image: buffer,
                    caption: args.length ? args.join(' ') : (media.imageMessage.caption || '👥 Group Status')
                });
                return sock.sendMessage(chatId, { text: '✅ *Group Status posted successfully.*' }, { quoted: message });
            }

            if (media.videoMessage) {
                const buffer = await mediaBuffer(media.videoMessage, 'video');
                await sendGroupStatus(sock, chatId, {
                    video: buffer,
                    caption: args.length ? args.join(' ') : (media.videoMessage.caption || '👥 Group Status')
                });
                return sock.sendMessage(chatId, { text: '✅ *Group Status posted successfully.*' }, { quoted: message });
            }

            if (sub === 'text') {
                const text = args.slice(1).join(' ').trim();
                if (!text) return sock.sendMessage(chatId, { text: '❌ Usage: `.groupstatus text Your status text`' }, { quoted: message });
                await sendGroupStatus(sock, chatId, { text });
                return sock.sendMessage(chatId, { text: '✅ *Group Status posted successfully.*' }, { quoted: message });
            }

            return sock.sendMessage(chatId, {
                text: '📢 *GROUP STATUS*\n\n• Reply to a photo/video → `.groupstatus`\n• Text → `.groupstatus text <message>`\n• Info → `.groupstatus info`'
            }, { quoted: message });
        } catch (error) {
            console.error('GroupStatus error:', error);
            const needsAdmin = /admin|permission|not-authorized|forbidden/i.test(String(error.message || ''));
            return sock.sendMessage(chatId, {
                text: `❌ *Group Status failed.*\n\n${needsAdmin ? 'Make the bot a group admin and try again.' : (error.message || 'Your current Baileys build may not support Group Status.')}`
            }, { quoted: message });
        }
    }
};
