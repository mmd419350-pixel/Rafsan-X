import fs from 'fs';
import path from 'path';

const FILE = path.join(process.cwd(), 'data', 'ownersocial.json');
const DEFAULTS = {
  facebook: 'https://facebook.com/example',
  tiktok: 'https://tiktok.com/@example',
  youtube: 'https://youtube.com/@example',
  whatsapp: '+8801000000000',
  contact: '+8801000000001'
};

function load() {
  try {
    if (!fs.existsSync(FILE)) fs.writeFileSync(FILE, JSON.stringify(DEFAULTS, null, 2));
    return { ...DEFAULTS, ...JSON.parse(fs.readFileSync(FILE, 'utf8')) };
  } catch { return { ...DEFAULTS }; }
}

export default {
  command: 'ownersocial',
  aliases: ['social', 'ownersocialinfo'],
  category: 'info',
  description: 'Show owner social and contact information',
  usage: '.ownersocial',
  async handler(sock, message, args, context) {
    const chatId = context.chatId || message.key.remoteJid;
    const d = load();
    const text = `╭━━━〔 🌐 OWNER SOCIAL 〕━━━╮
┃
┃ 📘 Facebook : ${d.facebook}
┃ 🎵 TikTok   : ${d.tiktok}
┃ ▶️ YouTube  : ${d.youtube}
┃ 💬 WhatsApp : ${d.whatsapp}
┃ ☎️ Contact  : ${d.contact}
┃
╰━━━━━━━━━━━━━━━━━━━━━━━━━━╯`;
    return sock.sendMessage(chatId, { text }, { quoted: message });
  }
};
