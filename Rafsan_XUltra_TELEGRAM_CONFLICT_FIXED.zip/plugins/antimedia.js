import fs from 'fs';
import path from 'path';
import { dataFile } from '../lib/paths.js';
import isAdmin from '../lib/isAdmin.js';

const FILE = dataFile('antimedia.json');
const cache = new Map();

function load() {
  if (cache.has('all')) return cache.get('all');
  try {
    if (!fs.existsSync(path.dirname(FILE))) fs.mkdirSync(path.dirname(FILE), { recursive: true });
    if (!fs.existsSync(FILE)) fs.writeFileSync(FILE, '{}');
    const d = JSON.parse(fs.readFileSync(FILE, 'utf8'));
    cache.set('all', d);
    return d;
  } catch { return {}; }
}
function save(d) {
  fs.mkdirSync(path.dirname(FILE), { recursive: true });
  fs.writeFileSync(FILE, JSON.stringify(d, null, 2));
  cache.set('all', d);
}
function isMedia(m) {
  const msg = m?.message || m || {};
  return !!(msg.imageMessage || msg.videoMessage);
}

export async function handleAntiMedia(sock, message, context = {}) {
  const chatId = context.chatId || message?.key?.remoteJid;
  if (!chatId?.endsWith('@g.us') || message?.key?.fromMe || !isMedia(message)) return false;
  const state = load();
  if (!state[chatId]?.enabled) return false;
  const senderId = message.key.participant || message.key.remoteJid;
  if (!senderId) return false;
  try {
    const a = await isAdmin(sock, chatId, senderId, { force: true });
    if (a?.isSenderAdmin) return false;
    if (!a?.isBotAdmin) return false;
    await sock.sendMessage(chatId, { delete: message.key }).catch(() => {});
    return true;
  } catch (e) {
    console.error('[ANTIMEDIA] delete failed:', e?.message || e);
    return false;
  }
}

export default {
  command: 'antimedia',
  aliases: ['antimediagroup', 'amedia'],
  category: 'admin',
  description: 'Delete group photo/video messages when enabled',
  usage: '.antimedia on|off|status',
  groupOnly: true,
  adminOnly: true,
  cooldown: 1500,
  async handler(sock, message, args, context) {
    const chatId = context.chatId || message.key.remoteJid;
    const state = load();
    const action = (args[0] || 'status').toLowerCase();
    if (!['on', 'off', 'status'].includes(action)) {
      return sock.sendMessage(chatId, { text: '🖼️ Use `.antimedia on`, `.antimedia off` or `.antimedia status`.' }, { quoted: message });
    }
    if (action === 'status') {
      return sock.sendMessage(chatId, { text: `🖼️ *ANTIMEDIA:* ${state[chatId]?.enabled ? '🟢 ON' : '🔴 OFF'}` }, { quoted: message });
    }
    state[chatId] = { ...(state[chatId] || {}), enabled: action === 'on' };
    save(state);
    return sock.sendMessage(chatId, { text: `🖼️ *ANTIMEDIA ${action === 'on' ? 'ON 🟢' : 'OFF 🔴'}*\n\n${action === 'on' ? 'Photo & video messages from non-admin members will be deleted.' : 'Media protection is disabled.'}` }, { quoted: message });
  }
};
