import fs from 'fs';
import path from 'path';
import { dataFile } from '../lib/paths.js';
import isAdmin from '../lib/isAdmin.js';

const STATE_FILE = dataFile('antiBot.json');
const stateCache = new Map();

function ensureFile() {
    const dir = path.dirname(STATE_FILE);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    if (!fs.existsSync(STATE_FILE)) fs.writeFileSync(STATE_FILE, JSON.stringify({}, null, 2));
}
function loadState() {
    if (stateCache.has('all')) return stateCache.get('all');
    try {
        ensureFile();
        const state = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
        stateCache.set('all', state);
        return state;
    } catch { return {}; }
}
function saveState(state) {
    ensureFile();
    fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2));
    stateCache.set('all', state);
}
function unwrap(message) {
    let m = message?.message || message;
    for (let i = 0; i < 5 && m; i++) {
        if (m.botInvokeMessage || m.botMessage) return m;
        if (m.ephemeralMessage?.message) { m = m.ephemeralMessage.message; continue; }
        if (m.viewOnceMessage?.message) { m = m.viewOnceMessage.message; continue; }
        if (m.viewOnceMessageV2?.message) { m = m.viewOnceMessageV2.message; continue; }
        break;
    }
    return m || {};
}

/**
 * Detect WhatsApp's explicit bot message containers. This intentionally does
 * not guess from usernames, because ordinary user names cannot reliably prove
 * that an account is a bot.
 */
export function isBotMessage(message) {
    const m = unwrap(message);
    return !!(m.botInvokeMessage || m.botMessage);
}

export async function handleAntiBot(sock, message, context = {}) {
    const chatId = context.chatId || message?.key?.remoteJid;
    if (!chatId?.endsWith('@g.us') || message?.key?.fromMe) return false;

    const state = loadState();
    if (!state[chatId]?.enabled || !isBotMessage(message)) return false;

    const senderId = message.key.participant || message.key.remoteJid;
    if (!senderId) return false;

    try {
        const admin = await isAdmin(sock, chatId, senderId, { force: true });
        // Never remove group admins/owner through AntiBot.
        if (admin?.isSenderAdmin) return false;
        if (!admin?.isBotAdmin) return false;
    } catch { return false; }

    try {
        // First delete the bot message, then remove the sender from the group.
        await sock.sendMessage(chatId, { delete: message.key }).catch(() => {});
        await sock.groupParticipantsUpdate(chatId, [senderId], 'remove');
        return true;
    } catch (error) {
        console.error('[ANTIBOT] remove failed:', error?.message || error);
        return false;
    }
}

export default {
    command: 'antibot',
    aliases: ['abot'],
    category: 'admin',
    description: 'Delete explicitly identified WhatsApp bot messages in groups',
    usage: '.antibot <on|off|status>',
    groupOnly: true,
    adminOnly: true,
    cooldown: 1500,
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const state = loadState();
        const action = (args[0] || '').toLowerCase();

        if (!['on', 'off', 'status'].includes(action)) {
            return sock.sendMessage(chatId, {
                text: '🤖 *ANTIBOT*\n\n• `.antibot on` — enable\n• `.antibot off` — disable\n• `.antibot status` — show status\n\n_Only explicit WhatsApp bot-message containers are targeted._'
            }, { quoted: message });
        }

        if (action === 'status') {
            return sock.sendMessage(chatId, {
                text: `🤖 *AntiBot:* ${state[chatId]?.enabled ? 'ON ✅' : 'OFF ❌'}`
            }, { quoted: message });
        }

        state[chatId] = { ...(state[chatId] || {}), enabled: action === 'on' };
        saveState(state);
        return sock.sendMessage(chatId, {
            text: `🤖 *AntiBot ${action === 'on' ? 'ON ✅' : 'OFF ❌'}*\n\nBot-message protection is now ${action === 'on' ? 'enabled' : 'disabled'}.`
        }, { quoted: message });
    }
};
