export default {
    command: 'tagall',
    aliases: ['everyone', 'all'],
    category: 'group',
    description: 'Tag all group members',
    usage: '.tagall',
    groupOnly: true,
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        try {
            const metadata = await sock.groupMetadata(chatId);
            const participants = metadata.participants || [];
            if (!participants.length) return sock.sendMessage(chatId, { text: '❌ No participants found.' }, { quoted: message });
            const mentions = participants.map(p => p.id).filter(Boolean);
            const lines = mentions.map((jid, i) => `${i + 1}. @${jid.split('@')[0]}`);
            const text = `╭━━━〔 📢 𝐓𝐀𝐆 𝐀𝐋𝐋 〕━━━╮\n┃ 🔔 সবাই একটু active হও!\n╰━━━━━━━━━━━━━━━━━━━━━━╯\n\n${lines.join('\n')}`;
            return sock.sendMessage(chatId, { text, mentions }, { quoted: message });
        } catch (error) {
            console.error('[TAGALL]', error);
            return sock.sendMessage(chatId, { text: `❌ Tagall failed: ${error.message}` }, { quoted: message });
        }
    }
};
