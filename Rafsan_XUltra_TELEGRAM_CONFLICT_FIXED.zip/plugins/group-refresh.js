/**
 * Group Refresh
 * Sends the refresh banner only to the group where the command was used.
 * This command does not require bot-admin privileges because it only sends text.
 */
const REFRESH_CONTEXT_INFO = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363426733881060@newsletter',
        newsletterName: '𝙓𝙖𝙛𝙨𝙖𝙣 𝙓 𝙏𝙖𝙘𝙝',
        serverMessageId: -1
    }
};

const REFRESH_MESSAGE = `𝐆𝐫𝐨𝐮𝐩 𝐑𝐞𝐟𝐫𝐞𝐬𝐡\n\n\n\n\n\n\n\n\n𝐆𝐫𝐨𝐮𝐩 𝐑𝐞𝐟𝐫𝐞𝐬𝐡\n\n\n\n\n\n\n\n\n𝐆𝐫𝐨𝐮𝐩 𝐑𝐞𝐟𝐫𝐞𝐬𝐡\n\n\n\n\n\n\n\n\n𝐆𝐫𝐨𝐮𝐩 𝐑𝐞𝐟𝐫𝐞𝐬𝐡\n\n\n\n\n\n\n\n𝐆𝐫𝐨𝐮𝐩 𝐑𝐞𝐟𝐫𝐞𝐬𝐡\n\n\n\n\n\n\n\n𝐆𝐫𝐨𝐮𝐩 𝐑𝐞𝐟𝐫𝐞𝐬𝐡\n\n\n\n\n\n\n\n𝐆𝐫𝐨𝐮𝐩 𝐑𝐞𝐟𝐫𝐞𝐬𝐡\n\n\n\n\n\n\n\n𝐆𝐫𝐨𝐮𝐩 𝐑𝐞𝐟𝐫𝐞𝐬𝐡\n\n\n\n\n\n\n\n𝐆𝐫𝐨𝐮𝐩 𝐑𝐞𝐟𝐫𝐞𝐬𝐡\n\n\n\n\n\n\n\n𝐆𝐫𝐨𝐮𝐩 𝐑𝐞𝐟𝐫𝐞𝐬𝐡\n\n\n\n\n\n\n\n𝐆𝐫𝐨𝐮𝐩 𝐑𝐞𝐟𝐫𝐞𝐬𝐡\n\n\n\n\n\n\n\n𝐆𝐫𝐨𝐮𝐩 𝐑𝐞𝐟𝐫𝐞𝐬𝐡\n\n\n\n\n\n\n\n𝐆𝐫𝐨𝐮𝐩 𝐑𝐞𝐟𝐫𝐞𝐬𝐡-𝐁𝐘😣💅\n\n𝐏𝐎𝐖𝐄𝐑 𝐁𝐘 𝐑𝐀𝐅𝐒𝐀𝐍 𝐁𝐁𝐙...💋`;

export default {
    command: 'group refresh',
    aliases: ['grouprefresh', 'refreshgroup'],
    category: 'group',
    description: 'Send the Group Refresh banner 3 times in this group',
    usage: '.group refresh',
    groupOnly: true,
    cooldown: 5000,
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        if (!chatId?.endsWith('@g.us')) return;

        for (let i = 0; i < 3; i++) {
            await sock.sendMessage(chatId, { text: REFRESH_MESSAGE, contextInfo: REFRESH_CONTEXT_INFO });
            if (i < 2) await new Promise(resolve => setTimeout(resolve, 350));
        }
    }
};
