import store from '../lib/lightweight_store.js';

export default {
  command: 'antiban', aliases: ['banprotect'], category: 'owner',
  description: 'Enable/disable safe anti-rate-limit protection for the bot',
  usage: '.antiban [on|off|status]', ownerOnly: true,
  async handler(sock, message, args, context) {
    const { chatId, channelInfo } = context;
    const action = (args[0] || 'status').toLowerCase();
    const key = 'antiban';
    const current = await store.getSetting('global', key) || { enabled: false };
    if (!['on','off','status'].includes(action)) return sock.sendMessage(chatId,{text:'❌ Use: .antiban on | off | status',...channelInfo},{quoted:message});
    if (action === 'status') return sock.sendMessage(chatId,{text:`🛡️ *ANTIBAN STATUS*\n\nStatus: ${current.enabled ? '🟢 ON' : '🔴 OFF'}\n\n_This reduces excessive/repeated bot requests; it cannot guarantee or bypass WhatsApp bans._`,...channelInfo},{quoted:message});
    current.enabled = action === 'on';
    await store.saveSetting('global', key, current);
    return sock.sendMessage(chatId,{text:`🛡️ *ANTIBAN ${current.enabled ? 'ENABLED' : 'DISABLED'}*\n\nSafe rate-limit/retry protection is now ${current.enabled ? 'active' : 'inactive'}.`,...channelInfo},{quoted:message});
  }
};
