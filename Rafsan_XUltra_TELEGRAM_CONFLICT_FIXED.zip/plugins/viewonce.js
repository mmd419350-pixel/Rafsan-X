import { downloadContentFromMessage, downloadMediaMessage, normalizeMessageContent } from '@whiskeysockets/baileys';

function getContext(message) {
    return message?.message?.extendedTextMessage?.contextInfo
        || message?.message?.conversation?.contextInfo
        || null;
}

function extractMedia(quoted) {
    const normalized = normalizeMessageContent(quoted) || quoted || {};
    const image = normalized.imageMessage;
    const video = normalized.videoMessage;
    if (image) return { type: 'image', media: image };
    if (video) return { type: 'video', media: video };
    return null;
}

function hasUsableMediaKey(media) {
    if (!media?.mediaKey) return false;
    try {
        return Buffer.from(media.mediaKey).length > 0;
    } catch {
        return false;
    }
}

async function streamToBuffer(stream) {
    const chunks = [];
    for await (const chunk of stream) chunks.push(Buffer.from(chunk));
    const buffer = Buffer.concat(chunks);
    if (!buffer.length) throw new Error('Downloaded media is empty.');
    return buffer;
}

async function downloadQuotedMedia(sock, message, quoted, mediaType, media) {
    // Preferred path: direct Baileys media download when the quoted payload
    // contains complete media encryption metadata.
    if (hasUsableMediaKey(media)) {
        try {
            return await streamToBuffer(await downloadContentFromMessage(media, mediaType));
        } catch (firstError) {
            // Fall through to downloadMediaMessage so Baileys can attempt its
            // normal media re-upload/retry flow.
            console.warn('[VIEWONCE] direct media download failed:', firstError?.message || firstError);
        }
    }

    const ctx = getContext(message) || {};
    const quotedKey = {
        remoteJid: message?.key?.remoteJid,
        fromMe: false,
        id: ctx.stanzaId || message?.key?.id,
        participant: ctx.participant || message?.key?.participant
    };

    const quotedWAMessage = {
        key: quotedKey,
        message: quoted
    };

    try {
        const buffer = await downloadMediaMessage(quotedWAMessage, 'buffer', {}, {
            logger: console,
            reuploadRequest: async (msg) => {
                if (typeof sock?.updateMediaMessage === 'function') {
                    return await sock.updateMediaMessage(msg);
                }
                return msg;
            }
        });
        if (buffer?.length) return Buffer.from(buffer);
    } catch (secondError) {
        console.warn('[VIEWONCE] fallback media download failed:', secondError?.message || secondError);
    }

    throw new Error('WhatsApp did not provide complete media encryption data. Reply to the original view-once image/video again and try .vv.');
}

export default {
    command: 'viewonce',
    aliases: ['viewmedia', 'vv'],
    category: 'general',
    description: 'Re-send a view-once image or video.',
    usage: '.vv (reply to a view-once image or video)',
    cooldown: 5000,
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        try {
            const ctx = getContext(message);
            const quoted = ctx?.quotedMessage;
            if (!quoted) {
                return await sock.sendMessage(chatId, {
                    text: '👁️ *View Once*\n\nReply directly to a view-once image or video with `.vv`.'
                }, { quoted: message });
            }

            const target = extractMedia(quoted);
            if (!target || !target.media?.viewOnce) {
                return await sock.sendMessage(chatId, {
                    text: '👁️ Please reply to a *view-once image or video*.'
                }, { quoted: message });
            }

            const buffer = await downloadQuotedMedia(sock, message, quoted, target.type, target.media);
            const payload = target.type === 'image'
                ? { image: buffer, caption: target.media.caption || '' }
                : { video: buffer, caption: target.media.caption || '' };

            await sock.sendMessage(chatId, payload, { quoted: message });
        } catch (error) {
            console.error('[VIEWONCE]', error?.stack || error);
            const safeMessage = String(error?.message || 'Unable to retrieve the media.');
            await sock.sendMessage(chatId, {
                text: `❌ *View-once media could not be retrieved.*\n\n${safeMessage}`
            }, { quoted: message });
        }
    }
};
