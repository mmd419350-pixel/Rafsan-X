import path from 'path';
import fs from 'fs';
import { pipeline } from 'stream/promises';

const MIME_TYPES = {
  '.mp4':'video/mp4','.pdf':'application/pdf','.zip':'application/zip',
  '.apk':'application/vnd.android.package-archive','.png':'image/png',
  '.jpg':'image/jpeg','.jpeg':'image/jpeg','.mp3':'audio/mpeg','.mkv':'video/x-matroska'
};
const formatBytes = bytes => {
  if (!Number.isFinite(bytes) || bytes <= 0) return '0 Bytes';
  const k=1024, sizes=['Bytes','KB','MB','GB','TB'];
  const i=Math.min(Math.floor(Math.log(bytes)/Math.log(k)), sizes.length-1);
  return `${(bytes/Math.pow(k,i)).toFixed(2)} ${sizes[i]}`;
};
function safeName(name='download') {
  return name.replace(/[^\w.\- ]+/g,'_').slice(0,120) || 'download';
}
export default {
  command:'Rafsan-X',
  aliases:['Rafsan-Xdl','rxfetch'],
  category:'download',
  description:'Download a file from a direct URL',
  usage:'.Rafsan-X <direct-file-url>',
  cooldown:5000,
  async handler(sock,message,args,context){
    const chatId=context.chatId||message.key.remoteJid;
    const url=args.join(' ').trim();
    if(!/^https?:\/\//i.test(url))
      return sock.sendMessage(chatId,{text:'📥 *Usage:* `.Rafsan-X https://example.com/file.mp4`\n\nOnly direct file URLs are supported.'},{quoted:message});
    let temp='';
    try{
      const controller=new AbortController();
      const timer=setTimeout(()=>controller.abort(),45000);
      const res=await fetch(url,{redirect:'follow',signal:controller.signal});
      clearTimeout(timer);
      if(!res.ok) throw new Error(`HTTP ${res.status}`);
      const type=(res.headers.get('content-type')||'').split(';')[0].toLowerCase();
      const length=Number(res.headers.get('content-length')||0);
      if(length>500*1024*1024) throw new Error('File exceeds 500 MB limit');
      const u=new URL(url);
      const fromPath=path.basename(u.pathname)||'download';
      const ext=path.extname(fromPath)||({ 'video/mp4':'.mp4','audio/mpeg':'.mp3','image/jpeg':'.jpg','image/png':'.png'}[type]||'');
      const fileName=safeName(path.extname(fromPath)?fromPath:`download${ext}`);
      const dir=path.join(process.cwd(),'temp','direct-downloads');
      fs.mkdirSync(dir,{recursive:true});
      temp=path.join(dir,`${Date.now()}_${fileName}`);
      if(!res.body) throw new Error('Empty response body');
      await pipeline(res.body,fs.createWriteStream(temp));
      const stat=fs.statSync(temp);
      if(stat.size>500*1024*1024) throw new Error('File exceeds 500 MB limit');
      const data=fs.readFileSync(temp);
      await sock.sendMessage(chatId,{
        document:data,
        fileName,
        mimetype:MIME_TYPES[path.extname(fileName).toLowerCase()]||type||'application/octet-stream',
        caption:`╭━━〔 📥 DOWNLOAD COMPLETE 〕━━╮\n┃ 📄 ${fileName}\n┃ 📦 ${formatBytes(stat.size)}\n╰━━━━━━━━━━━━━━━━━━━━━━╯`
      },{quoted:message});
    }catch(e){
      await sock.sendMessage(chatId,{text:`❌ *Download failed:* ${e.name==='AbortError'?'Request timed out':e.message}`},{quoted:message});
    }finally{
      if(temp) try{fs.rmSync(temp,{force:true});}catch{}
    }
  }
};
