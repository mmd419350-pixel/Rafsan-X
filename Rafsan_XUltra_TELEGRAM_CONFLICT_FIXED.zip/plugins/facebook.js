import { resolveFacebook, downloadBuffer } from '../lib/mediaDownloaders.js';

export default {
  command: 'facebook', aliases: ['fb', 'fbdl'], category: 'download',
  description: 'Download Facebook videos', usage: '.fb <Facebook video link>', cooldown: 3000,
  async handler(sock, message, args, context) {
    const chatId = context.chatId || message.key.remoteJid;
    const url = args.join(' ').trim();
    if (!url) return sock.sendMessage(chatId, { text: '📘 *FACEBOOK DOWNLOADER*\n\nUsage: `.fb <facebook video link>`' }, { quoted: message });
    if (!/(facebook\.com|fb\.watch|m\.facebook\.com)/i.test(url)) return sock.sendMessage(chatId, { text: '❌ Please send a valid Facebook video link.' }, { quoted: message });
    try {
      await sock.sendMessage(chatId, { react: { text: '🔄', key: message.key } });
      const result = await resolveFacebook(url);
      const caption = `📘 *Facebook Downloader*\n\n📝 ${result.title || 'Facebook Video'}\n\n⚡ *Rafsan-XUltra*`;
      try {
        await sock.sendMessage(chatId, { video: { url: result.videoUrl }, mimetype: 'video/mp4', caption }, { quoted: message });
      } catch (directError) {
        console.error('[FACEBOOK] direct send failed:', directError.message);
        const buffer = await downloadBuffer(result.videoUrl, { maxContentLength: 90 * 1024 * 1024, maxBodyLength: 90 * 1024 * 1024, headers: { Referer: 'https://www.facebook.com/' } });
        await sock.sendMessage(chatId, { video: buffer, mimetype: 'video/mp4', caption }, { quoted: message });
      }
    } catch (error) {
      console.error('[FACEBOOK]', error);
      await sock.sendMessage(chatId, { text: `❌ *Facebook download failed.*\n\n${error?.message || 'All available Facebook providers failed.'}` }, { quoted: message });
    }
  }
};
