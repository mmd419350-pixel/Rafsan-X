import { handleWelcome } from '../lib/welcome.js';
import { isWelcomeOn, getWelcome } from '../lib/index.js';

import { resolveParticipantMention } from '../lib/participantMention.js';

async function handleJoinEvent(sock, id, participants) {
    const isWelcomeEnabled = await isWelcomeOn(id);
    if (!isWelcomeEnabled) return;

    const customMessage = await getWelcome(id);
    const groupMetadata = await sock.groupMetadata(id);
    const groupName = groupMetadata.subject || 'Our Group';
    const groupDesc = groupMetadata.desc || 'No description available';
    const memberCount = groupMetadata.participants?.length || 0;

    for (const participant of participants || []) {
        try {
            const { mentionJid, displayName } = await resolveParticipantMention(sock, groupMetadata, participant);
            if (!mentionJid) {
                console.warn('[WELCOME] Could not resolve a mention target; skipping this participant.');
                continue;
            }
            const mentionText = `@${displayName}`;
            const finalMessage = customMessage
                ? customMessage
                    .replace(/{user}/g, mentionText)
                    .replace(/{group}/g, groupName)
                    .replace(/{description}/g, groupDesc)
                    .replace(/{count}/g, String(memberCount))
                : `╭━━〔 🌸 𝐖𝐄𝐋𝐂𝐎𝐌𝐄 / 𝐒𝐖𝐀𝐆𝐀𝐓𝐎𝐌 🌸 〕━━╮
┃ 👤 Member : ${mentionText}
┃ 👥 Members : ${memberCount}
┃ 🏠 Group : ${groupName}
╰━━━━━━━━━━━━━━━━━━━━╯

🎉 *Welcome to the family, ${mentionText}!* 
✨ নতুন journey শুরু হোক respect, friendship আর good vibes দিয়ে।
💬 *Rules মেনে চলুন • Active থাকুন • Enjoy করুন* 🤍
🤲 *May your stay here be peaceful, memorable & blessed.*

🤖 *Rafsan-XUltra • Premium Group Assistant*`;

            await sock.sendMessage(id, { text: finalMessage, mentions: [mentionJid] });
        } catch (error) {
            console.error('[WELCOME]', error);
        }
    }
}

export default {
    command: 'welcome',
    aliases: ['setwelcome'],
    category: 'admin',
    description: 'Configure welcome message for the group',
    usage: '.welcome [on/off/set message]',
    groupOnly: true,
    adminOnly: true,
    async handler(sock, message, args, context) {
        const { chatId } = context;
        await handleWelcome(sock, chatId, message, args.join(' '));
    }
};

export { handleJoinEvent };
