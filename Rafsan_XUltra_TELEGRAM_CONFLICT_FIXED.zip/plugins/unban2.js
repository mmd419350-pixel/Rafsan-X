import { setGroupBotEnabled } from './botgroup.js';

export default {
    command: 'unban2',
    aliases: [],
    category: 'admin',
    description: 'Enable this bot session only in the current group',
    usage: '.unban2',
    groupOnly: true,
    adminOnly: true,
    cooldown: 1000,
    async handler(sock, message, _args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const sessionId = sock.sessionKey || 'main';
        await setGroupBotEnabled(chatId, true, sessionId);
        await sock.sendMessage(chatId, {
            text: `╭━━〔 🟢 BOT ON — THIS GROUP ONLY 〕━━╮
┃
┃ ✅ Status : ON
┃ 🆔 Session : ${sessionId}
┃
┃ এই group-এ এই bot session আবার active।
┃ অন্য group/session-এর settings বদলাবে না।
┃
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯`
        }, { quoted: message });
    }
};
