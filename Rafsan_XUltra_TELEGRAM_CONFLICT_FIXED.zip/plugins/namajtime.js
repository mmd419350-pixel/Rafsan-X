import fs from 'fs';
import path from 'path';
import axios from 'axios';
import moment from 'moment-timezone';
import { dataFile } from '../lib/paths.js';
import isAdmin from '../lib/isAdmin.js';

const STATE_FILE = dataFile('namajtime.json');
const TZ = 'Asia/Dhaka';
const CITY = 'Dhaka';
const COUNTRY = 'Bangladesh';
const METHOD = 1; // Karachi method; commonly used in South Asia
const SCHOOL = 1; // Hanafi Asr
const PRAYERS = [
  ['Fajr', 'ফজর'],
  ['Dhuhr', 'যোহর'],
  ['Asr', 'আসর'],
  ['Maghrib', 'মাগরিব'],
  ['Isha', 'এশা']
];

const stateCache = { data: null, loadedAt: 0 };
const timingCache = new Map();
const fired = new Set();
const mutedGroups = new Map();
let schedulerStarted = false;

function ensureFile() {
  const dir = path.dirname(STATE_FILE);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  if (!fs.existsSync(STATE_FILE)) fs.writeFileSync(STATE_FILE, JSON.stringify({}, null, 2));
}
function loadState() {
  if (stateCache.data && Date.now() - stateCache.loadedAt < 15000) return stateCache.data;
  try {
    ensureFile();
    stateCache.data = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
  } catch {
    stateCache.data = {};
  }
  stateCache.loadedAt = Date.now();
  return stateCache.data;
}
function saveState(state) {
  ensureFile();
  fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2));
  stateCache.data = state;
  stateCache.loadedAt = Date.now();
}
function todayKey() {
  return moment.tz(TZ).format('YYYY-MM-DD');
}
function dateApiKey() {
  return moment.tz(TZ).format('DD-MM-YYYY');
}

async function getPrayerTimes() {
  const key = dateApiKey();
  const cached = timingCache.get(key);
  if (cached && cached.expires > Date.now()) return cached.timings;

  const urls = [
    `https://api.aladhan.com/v1/timingsByCity/${key}?city=${encodeURIComponent(CITY)}&country=${encodeURIComponent(COUNTRY)}&method=${METHOD}&school=${SCHOOL}`,
    `https://api.aladhan.com/v1/timingsByCity?city=${encodeURIComponent(CITY)}&country=${encodeURIComponent(COUNTRY)}&method=${METHOD}&school=${SCHOOL}`
  ];

  let lastError = null;
  for (const url of urls) {
    try {
      const { data } = await axios.get(url, {
        timeout: 10000,
        headers: { Accept: 'application/json', 'User-Agent': 'Rafsan-X/6.0' }
      });
      const timings = data?.data?.timings;
      if (timings?.Fajr && timings?.Dhuhr && timings?.Asr && timings?.Maghrib && timings?.Isha) {
        timingCache.clear();
        timingCache.set(key, { timings, expires: Date.now() + 12 * 60 * 60 * 1000 });
        return timings;
      }
      lastError = new Error('Prayer API returned incomplete timings');
    } catch (e) {
      lastError = e;
    }
  }
  throw lastError || new Error('Prayer API unavailable');
}

function parseTodayTime(value) {
  const clean = String(value || '').trim().split(' ')[0];
  const m = clean.match(/^(\d{1,2}):(\d{2})$/);
  if (!m) return null;
  return moment.tz(`${todayKey()} ${m[1].padStart(2, '0')}:${m[2]}`, 'YYYY-MM-DD HH:mm', TZ);
}

function botIdentitySet(sock) {
  const out = new Set();
  const vals = [
    sock.user?.id, sock.user?.lid, sock.user?.jid,
    sock.authState?.creds?.me?.id, sock.authState?.creds?.me?.lid
  ];
  for (const v of vals) {
    if (!v) continue;
    const s = String(v);
    out.add(s);
    out.add(s.split(':')[0]);
    out.add(s.split('@')[0]);
  }
  return out;
}

async function temporaryMute(sock, chatId, minutes = 10) {
  if (mutedGroups.has(chatId)) return;
  try {
    const metadata = await sock.groupMetadata(chatId);
    if (metadata?.announce === true) return;

    await sock.groupSettingUpdate(chatId, 'announcement');
    const timer = setTimeout(async () => {
      try {
        const current = await sock.groupMetadata(chatId);
        if (current?.announce === true) {
          await sock.groupSettingUpdate(chatId, 'not_announcement');
        }
      } catch (e) {
        console.error('[NAMAJ] unmute failed:', e.message);
      } finally {
        mutedGroups.delete(chatId);
      }
    }, minutes * 60 * 1000);

    mutedGroups.set(chatId, timer);
  } catch (e) {
    console.error(`[NAMAJ] mute failed for ${chatId}:`, e.message);
  }
}

async function announcePrayer(sock, chatId, key, bn, time) {
  const state = loadState();
  const cfg = state[chatId];
  if (!cfg?.enabled) return;

  const id = `${chatId}:${todayKey()}:${key}`;
  if (fired.has(id)) return;
  fired.add(id);

  const text =
`🕌 *${bn} এর আজান* 🕌

⏰ সময়: *${time}* (Dhaka)
🤲 নামাজের সময় হয়েছে।
🌙 সবাই অনুগ্রহ করে নামাজের প্রস্তুতি নিন।
✨ আল্লাহ আমাদের সবাইকে নামাজ আদায় করার তাওফিক দিন। আমিন।`;

  try {
    await sock.sendMessage(chatId, { text });
  } catch (e) {
    console.error(`[NAMAJ] notification failed ${chatId}:`, e.message);
  }

  if (cfg.mute !== false) {
    try {
      const botIds = botIdentitySet(sock);
      const metadata = await sock.groupMetadata(chatId);
      const botParticipant = (metadata?.participants || []).find(p => {
        const vals = [p.id, p.lid, p.phoneNumber, p.jid].filter(Boolean).flatMap(v => {
          const s = String(v);
          return [s, s.split(':')[0], s.split('@')[0]];
        });
        return vals.some(v => botIds.has(v));
      });
      if (botParticipant?.admin === 'admin' || botParticipant?.admin === 'superadmin') {
        await temporaryMute(sock, chatId, Number(cfg.muteMinutes) || 10);
      }
    } catch (e) {
      console.error(`[NAMAJ] admin/mute check failed ${chatId}:`, e.message);
    }
  }
}

export async function startPrayerAlertScheduler(sock) {
  if (schedulerStarted) return;
  schedulerStarted = true;

  // Warm the API cache once at startup; failures are retried by the interval.
  getPrayerTimes().catch(e => console.error('[NAMAJ] initial prayer fetch:', e.message));

  setInterval(async () => {
    try {
      const state = loadState();
      const enabledGroups = Object.entries(state).filter(([, cfg]) => cfg?.enabled);
      if (!enabledGroups.length) return;

      const timings = await getPrayerTimes();
      const now = moment.tz(TZ);

      for (const [chatId] of enabledGroups) {
        for (const [key, bn] of PRAYERS) {
          const t = parseTodayTime(timings[key]);
          if (!t) continue;

          const diff = now.diff(t, 'seconds');
          // 0–90 sec window prevents a short scheduler/network delay from missing the prayer.
          if (diff >= 0 && diff <= 90) {
            await announcePrayer(sock, chatId, key, bn, t.format('hh:mm A'));
          }
        }
      }

      if (fired.size > 10000) {
        const today = todayKey();
        for (const id of fired) {
          if (!id.includes(`:${today}:`)) fired.delete(id);
        }
      }
    } catch (e) {
      console.error('[NAMAJ] scheduler error:', e.message);
    }
  }, 15000);
}

export default {
  command: 'namajtime',
  aliases: ['prayer', 'azan', 'salat'],
  category: 'group',
  description: 'Automatic Dhaka prayer-time notifications and temporary group mute',
  usage: '.namajtime <on|off|status|times|mute on|mute off>',
  groupOnly: true,
  adminOnly: true,
  cooldown: 1500,

  async handler(sock, message, args, context) {
    const chatId = context.chatId || message.key.remoteJid;
    const state = loadState();
    const action = (args[0] || '').toLowerCase();
    const sub = (args[1] || '').toLowerCase();
    const cfg = state[chatId] || { enabled: false, mute: true, muteMinutes: 10 };

    await startPrayerAlertScheduler(sock);

    if (action === 'times') {
      try {
        const timings = await getPrayerTimes();
        const text = PRAYERS.map(([en, bn]) => `🕌 ${bn} (${en}): *${timings[en]}*`).join('\n');
        return sock.sendMessage(chatId, {
          text: `🕌 *আজকের নামাজের সময় — Dhaka*\n\n${text}\n\n📍 Timezone: Asia/Dhaka`
        }, { quoted: message });
      } catch (e) {
        return sock.sendMessage(chatId, { text: `❌ Prayer time fetch failed: ${e.message}` }, { quoted: message });
      }
    }

    if (action === 'status') {
      return sock.sendMessage(chatId, {
        text:
`🕌 *NAMAJTIME STATUS*

🔔 Notification: ${cfg.enabled ? 'ON ✅' : 'OFF ❌'}
🔇 Auto mute: ${cfg.mute !== false ? 'ON ✅' : 'OFF ❌'}
⏱️ Mute duration: ${cfg.muteMinutes || 10} minutes
📍 Timezone: Asia/Dhaka`
      }, { quoted: message });
    }

    if (action === 'mute' && (sub === 'on' || sub === 'off')) {
      state[chatId] = { ...cfg, mute: sub === 'on' };
      saveState(state);
      return sock.sendMessage(chatId, {
        text: `🔇 Namaj auto-mute is now *${sub === 'on' ? 'ON ✅' : 'OFF ❌'}*.`
      }, { quoted: message });
    }

    if (action === 'on' || action === 'off') {
      state[chatId] = { ...cfg, enabled: action === 'on' };
      saveState(state);
      return sock.sendMessage(chatId, {
        text:
`🕌 *NAMAJTIME ${action === 'on' ? 'ON 🟢' : 'OFF 🔴'}*

${action === 'on'
  ? 'Automatic Fajr, Dhuhr, Asr, Maghrib and Isha notifications are enabled.'
  : 'Automatic prayer notifications are disabled.'}

📍 Dhaka / Asia-Dhaka
🔇 Auto mute: ${state[chatId].mute ? 'ON' : 'OFF'}`
      }, { quoted: message });
    }

    return sock.sendMessage(chatId, {
      text:
`🕌 *NAMAJTIME*

• .namajtime on
• .namajtime off
• .namajtime status
• .namajtime times
• .namajtime mute on
• .namajtime mute off

📍 Dhaka • Asia/Dhaka
🔔 Fajr • Dhuhr • Asr • Maghrib • Isha
🔇 Auto mute works when the bot is a group admin.`
    }, { quoted: message });
  }
};
