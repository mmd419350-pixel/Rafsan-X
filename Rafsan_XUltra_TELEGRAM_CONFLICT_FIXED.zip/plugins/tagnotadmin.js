export default {
    command: 'tagnotadmin',
    aliases: ['tagmembers', 'tagnon'],
    category: 'group',
    description: 'Tag all non-admin members',
    usage: '.tagnotadmin',
    groupOnly: true,
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        try {
            const metadata = await sock.groupMetadata(chatId);
            const participants = metadata.participants || [];
            const nonAdmins = participants.filter(p => !p.admin).map(p => p.id).filter(Boolean);
            if (!nonAdmins.length) return sock.sendMessage(chatId, { text: 'ℹ️ No non-admin members found.' }, { quoted: message });
            const text = `╭━━〔 🔔 𝐍𝐎𝐍-𝐀𝐃𝐌𝐈𝐍 〕━━╮\n┃ সবাই একটু active হও!\n╰━━━━━━━━━━━━━━━━━━━━━━╯\n\n${nonAdmins.map((jid, i) => `${i + 1}. @${jid.split('@')[0]}`).join('\n')}`;
            await sock.sendMessage(chatId, { text, mentions: nonAdmins }, { quoted: message });
        } catch (error) {
            console.error('[TAGNOTADMIN]', error);
            await sock.sendMessage(chatId, { text: `❌ Tag non-admin failed: ${error.message}` }, { quoted: message });
        }
    }
};
