# Rafsan-X pairing fixes

- Pairing now uses the WhatsApp version advertised by the installed Baileys build instead of mixing it with the live WA-Web revision.
- Pairing requests can begin when the socket reaches `connecting` or emits a QR event; the old QR-only gate was removed.
- Added a short handshake settle delay before `requestPairingCode()`.
- Failed fresh pairing sockets are cleaned up so a failed attempt does not leave a stale "already being paired" state.
- Unregistered pairing sockets are not automatically reconnected after a close; a new `/pair` request creates a fresh session.
- Concurrent pairing requests for the same number are guarded by an in-process pending-pair lock.
- `ban2` and `unban2` remain manual group-admin commands and their state is stored per WhatsApp session and per group.
- JavaScript syntax check passes for all project JS files.

Note: WhatsApp can still reject a pairing request because of server/network/account-side restrictions. No code change can guarantee zero 405/515 errors or guarantee that an account will never be banned.
