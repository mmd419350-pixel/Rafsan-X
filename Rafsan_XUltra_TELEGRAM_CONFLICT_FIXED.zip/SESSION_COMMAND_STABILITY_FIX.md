# Rafsan-XUltra — Long-Session Command Stability Fix

## Problem found
Paired sessions could remain visible as active while the underlying WhatsApp WebSocket became half-open. In that state the panel/session looked online, but incoming command traffic could stop reaching the command pipeline. The previous reconnect code only reacted after Baileys emitted `connection: close`, so a half-open socket could remain stuck indefinitely.

There was also a strict `notify`-only message gate. A very recent message delivered as `append` after a reconnect was discarded, which could make a newly reconnected session appear alive while a command was ignored.

## Fixes applied
- Added a **per-session health watchdog** to paired sessions.
- Every 4 minutes, the watchdog checks the WebSocket state and sends a lightweight `available` presence probe.
- Probe timeout/failure forces the existing reconnect path to replace the stale socket using saved credentials.
- Health timers are cleared on session close, unpair, stale-socket replacement, and failed pairing.
- Added session-local health metadata (`lastHealthCheck`, `lastEventAt`, `lastMessageAt`).
- `messages.upsert` now records activity per session before entering the command pipeline.
- Recent `append` messages (<=90 seconds old) are accepted safely; old history is still ignored.
- Added a per-socket message-ID dedupe guard so reconnect/event duplication cannot execute the same command repeatedly.
- Updated the integration test to cover safe recent-append handling.

## Important
This prevents the specific class of **half-open/stale WebSocket** failures that can cause commands to stop after many hours while the session still looks active. It cannot guarantee that WhatsApp itself will never log out or reject a session.

The package dependency tree was not installed in the working environment, so a full live WhatsApp integration test could not be performed here. The modified JavaScript files and the modified test file passed `node --check` syntax validation.
