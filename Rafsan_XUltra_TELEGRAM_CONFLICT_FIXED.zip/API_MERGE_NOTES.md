# Xafsan-xmd API merge — Rafsan-XUltra

This build keeps the Rafsan-XUltra plugin architecture and merges the working downloader providers used by Xafsan-xmd.

## Media providers
- Song / Play: NeoSoft YouTube downloader (`https://api.neosoft.best/api/downloader/youtube`)
- TikTok: Siputzx first, `ruhend-scraper` fallback
- Facebook: Hanggts first, existing GTech fallback
- Instagram: `ruhend-scraper`
- Snapchat: existing Discard API

All media endpoints are configurable in `config.js` under `mediaApis` and optional API keys under `mediaApiKeys`.

## Reliability changes
- Removed direct `api-qasim` constructor usage from play/song/tiktok plugins, avoiding the previous `API is not a constructor` loader failure.
- Added provider fallbacks and URL/buffer sending fallback for media that rejects WhatsApp's direct fetch.
- Song/play now restore the thumbnail + title + duration details message before sending the MP3.
- Welcome/goodbye now resolve WhatsApp LID participants to a real WhatsApp JID when available, so mentions are used instead of raw LID IDs.
